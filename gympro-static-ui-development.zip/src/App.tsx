import { useState, useEffect } from "react";
import { AnimatePresence, motion } from "framer-motion";

// Layout
import { Sidebar } from "@/components/layout/Sidebar";
import { BottomNav } from "@/components/layout/BottomNav";
import { TopBar } from "@/components/layout/TopBar";

// Screens
import { SplashScreen } from "@/screens/SplashScreen";
import { AuthScreen } from "@/screens/AuthScreen";
import { OnboardingScreen } from "@/screens/OnboardingScreen";
import { DashboardScreen } from "@/screens/DashboardScreen";
import { ExercisesScreen } from "@/screens/ExercisesScreen";
import { RoutinesScreen } from "@/screens/RoutinesScreen";
import { WorkoutScreen } from "@/screens/WorkoutScreen";
import { HistoryScreen } from "@/screens/HistoryScreen";
import { NutritionScreen } from "@/screens/NutritionScreen";
import { ProgressScreen } from "@/screens/ProgressScreen";
import { CalculatorsScreen } from "@/screens/CalculatorsScreen";
import { CommunityScreen } from "@/screens/CommunityScreen";
import { ProfileScreen } from "@/screens/ProfileScreen";
import { AdminScreen } from "@/screens/AdminScreen";

type Page =
  | "splash" | "auth" | "onboarding"
  | "dashboard" | "exercises" | "routines" | "workout"
  | "history" | "nutrition" | "progress" | "calculators"
  | "community" | "profile" | "admin" | "settings";

const pageTitles: Record<Page, string> = {
  splash: "GymPro",
  auth: "Bienvenido",
  onboarding: "Configuración inicial",
  dashboard: "¡Hola, Carlos! 👋",
  exercises: "Biblioteca de Ejercicios",
  routines: "Mis Rutinas",
  workout: "Entrenamiento en Vivo 🔴",
  history: "Historial",
  nutrition: "Nutrición",
  progress: "Mi Progreso",
  calculators: "Calculadoras",
  community: "Comunidad",
  profile: "Mi Perfil",
  admin: "Panel Admin",
  settings: "Configuración",
};

const noLayoutPages: Page[] = ["splash", "auth", "onboarding"];

const pageVariants = {
  initial: { opacity: 0, y: 12 },
  animate: { opacity: 1, y: 0 },
  exit: { opacity: 0, y: -8 },
};

export default function App() {
  const [currentPage, setCurrentPage] = useState<Page>("splash");
  const [darkMode, setDarkMode] = useState(false);

  // Apply dark mode class to <html>
  useEffect(() => {
    const html = document.documentElement;
    if (darkMode) {
      html.classList.add("dark");
    } else {
      html.classList.remove("dark");
    }
  }, [darkMode]);

  const toggleDark = () => setDarkMode(d => !d);

  const navigate = (page: string) => {
    setCurrentPage(page as Page);
  };

  const isFullscreen = noLayoutPages.includes(currentPage);

  const renderScreenContent = () => {
    switch (currentPage) {
      case "dashboard": return <DashboardScreen onNavigate={navigate} />;
      case "exercises": return <ExercisesScreen />;
      case "routines": return <RoutinesScreen onNavigate={navigate} />;
      case "workout": return <WorkoutScreen />;
      case "history": return <HistoryScreen />;
      case "nutrition": return <NutritionScreen />;
      case "progress": return <ProgressScreen />;
      case "calculators": return <CalculatorsScreen />;
      case "community": return <CommunityScreen />;
      case "profile": return <ProfileScreen darkMode={darkMode} onToggleDark={toggleDark} onNavigate={navigate} />;
      case "admin": return <AdminScreen />;
      case "settings": return (
        <div className="flex flex-col items-center justify-center py-20 text-slate-400">
          <span className="text-6xl mb-4">⚙️</span>
          <p className="font-bold text-slate-700 dark:text-slate-300 text-lg">Configuración</p>
          <p className="text-sm">Próximamente disponible</p>
        </div>
      );
      default: return <DashboardScreen onNavigate={navigate} />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-50 transition-colors duration-300">
      {/* Fullscreen pages (splash, auth, onboarding) */}
      <AnimatePresence mode="wait">
        {currentPage === "splash" && (
          <motion.div
            key="splash"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0, scale: 1.05 }}
            transition={{ duration: 0.4 }}
            className="fixed inset-0 z-50"
          >
            <SplashScreen onFinish={() => navigate("auth")} />
          </motion.div>
        )}

        {currentPage === "auth" && (
          <motion.div
            key="auth"
            initial={{ opacity: 0, scale: 0.98 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.98 }}
            transition={{ duration: 0.3 }}
            className="fixed inset-0 z-40"
          >
            <AuthScreen onNavigate={navigate} />
          </motion.div>
        )}

        {currentPage === "onboarding" && (
          <motion.div
            key="onboarding"
            initial={{ opacity: 0, x: 80 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -80 }}
            transition={{ duration: 0.35, ease: "easeOut" }}
            className="fixed inset-0 z-40"
          >
            <OnboardingScreen onNavigate={navigate} />
          </motion.div>
        )}
      </AnimatePresence>

      {/* Main app layout (not shown during fullscreen pages) */}
      {!isFullscreen && (
        <div className="flex min-h-screen">
          {/* Desktop Sidebar */}
          <Sidebar currentPage={currentPage} onNavigate={navigate} />

          {/* Main content area */}
          <div className="flex-1 lg:ml-64 flex flex-col min-h-screen">
            {/* TopBar */}
            <TopBar
              title={pageTitles[currentPage]}
              darkMode={darkMode}
              onToggleDark={toggleDark}
              onNavigate={navigate}
            />

            {/* Page content */}
            <main className="flex-1 p-4 lg:p-6 pb-24 lg:pb-8 overflow-x-hidden">
              <div className="max-w-5xl mx-auto">
                <AnimatePresence mode="wait">
                  <motion.div
                    key={currentPage}
                    variants={pageVariants}
                    initial="initial"
                    animate="animate"
                    exit="exit"
                    transition={{ duration: 0.22, ease: "easeOut" }}
                  >
                    {renderScreenContent()}
                  </motion.div>
                </AnimatePresence>
              </div>
            </main>
          </div>

          {/* Mobile bottom navigation */}
          <BottomNav currentPage={currentPage} onNavigate={navigate} />
        </div>
      )}
    </div>
  );
}
