import React from "react";
import { motion } from "framer-motion";
import {
  Flame, Droplets, Footprints, Moon, TrendingUp, PlayCircle,
  Clock, Award, Star, ChevronRight, Zap, Activity,
  Scale, Dumbbell
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/Card";
import { Badge } from "@/components/ui/Badge";
import { Progress } from "@/components/ui/Progress";

interface DashboardScreenProps {
  onNavigate: (page: string) => void;
}

const fadeUp = {
  hidden: { opacity: 0, y: 20 },
  visible: (i: number) => ({ opacity: 1, y: 0, transition: { delay: i * 0.08, duration: 0.4 } }),
};

const achievements = [
  { icon: "🏆", label: "Primer mes", color: "from-amber-400 to-yellow-500" },
  { icon: "🔥", label: "12 días racha", color: "from-orange-400 to-red-500" },
  { icon: "💪", label: "100kg Press", color: "from-indigo-400 to-purple-500" },
  { icon: "⚡", label: "50 sesiones", color: "from-blue-400 to-cyan-500" },
  { icon: "🎯", label: "Meta semanal", color: "from-emerald-400 to-green-500" },
];

const waterGlasses = [true, true, true, true, true, true, false, false];

export const DashboardScreen: React.FC<DashboardScreenProps> = ({ onNavigate }) => {
  return (
    <div className="space-y-6 pb-6">
      {/* Welcome header */}
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-gradient-to-r from-indigo-600 via-indigo-500 to-purple-600 rounded-2xl p-5 text-white relative overflow-hidden"
      >
        <div className="absolute top-0 right-0 w-40 h-40 bg-white/10 rounded-full -translate-y-1/2 translate-x-1/2" />
        <div className="absolute bottom-0 left-1/2 w-24 h-24 bg-white/5 rounded-full translate-y-1/2" />
        <div className="relative">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-indigo-200 text-sm font-medium">¡Buenos días! 👋</p>
              <h2 className="text-2xl font-black mt-0.5">Carlos Andrés</h2>
              <div className="flex items-center gap-3 mt-2">
                <Badge className="bg-white/20 text-white border-0">
                  <Flame size={12} className="animate-flicker" />
                  Racha: 12 días 🔥
                </Badge>
                <Badge className="bg-white/20 text-white border-0">
                  ⭐ Nivel Intermedio
                </Badge>
              </div>
            </div>
            <div className="text-right">
              <div className="text-3xl font-black">78 kg</div>
              <p className="text-indigo-200 text-xs mt-0.5">Peso actual</p>
              <p className="text-xs text-indigo-300 mt-1">Meta: 75 kg</p>
              <div className="mt-2 w-20 h-1.5 bg-white/20 rounded-full ml-auto overflow-hidden">
                <div className="h-full bg-white rounded-full" style={{ width: "60%" }} />
              </div>
            </div>
          </div>
        </div>
      </motion.div>

      {/* Today's workout */}
      <motion.div custom={1} initial="hidden" animate="visible" variants={fadeUp}>
        <Card className="border-indigo-200 dark:border-indigo-800/50 bg-gradient-to-r from-indigo-50 to-purple-50 dark:from-indigo-950/30 dark:to-purple-950/30">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center shadow-md">
                  <Dumbbell size={22} className="text-white" />
                </div>
                <div>
                  <p className="text-xs text-slate-500 dark:text-slate-400 font-medium">HOY · PRÓXIMO</p>
                  <p className="font-bold text-slate-800 dark:text-slate-100">Rutina de Pierna 🦵</p>
                  <p className="text-xs text-slate-500 dark:text-slate-400">8 ejercicios · ~55 min</p>
                </div>
              </div>
              <button
                onClick={() => onNavigate("workout")}
                className="flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-xl text-sm font-bold hover:bg-indigo-700 transition-colors shadow-md btn-press"
              >
                <PlayCircle size={16} />
                Iniciar
              </button>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Stats grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {[
          { icon: <Clock size={18} className="text-blue-500" />, label: "Esta semana", value: "3h 45min", sub: "Entrenado", color: "blue" },
          { icon: <Footprints size={18} className="text-emerald-500" />, label: "Pasos hoy", value: "8,234", sub: "Meta: 10,000", color: "emerald" },
          { icon: <Moon size={18} className="text-purple-500" />, label: "Sueño", value: "7h 20min", sub: "Calidad: Buena", color: "purple" },
          { icon: <Activity size={18} className="text-orange-500" />, label: "Calorías quem.", value: "487 kcal", sub: "Meta: 500 kcal", color: "orange" },
        ].map((stat, i) => (
          <motion.div key={stat.label} custom={i + 2} initial="hidden" animate="visible" variants={fadeUp}>
            <Card hover className="h-full">
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-2">
                  <div className={`p-2 rounded-xl bg-${stat.color}-50 dark:bg-${stat.color}-950/30`}>
                    {stat.icon}
                  </div>
                </div>
                <p className="text-xl font-black text-slate-800 dark:text-slate-100">{stat.value}</p>
                <p className="text-xs font-semibold text-slate-700 dark:text-slate-300">{stat.label}</p>
                <p className="text-xs text-slate-400 dark:text-slate-500">{stat.sub}</p>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      {/* Calories + Macros */}
      <motion.div custom={6} initial="hidden" animate="visible" variants={fadeUp}>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {/* Calories */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  <Flame size={18} className="text-orange-500" />
                  Calorías diarias
                </CardTitle>
                <Badge variant="warning">84%</Badge>
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-center mb-4">
                <span className="text-4xl font-black text-slate-800 dark:text-slate-100">1,850</span>
                <span className="text-slate-400 text-lg"> / 2,200</span>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">kcal consumidas</p>
              </div>
              <Progress value={1850} max={2200} color="bg-gradient-to-r from-orange-400 to-red-500" size="md" />

              {/* Macros */}
              <div className="mt-4 space-y-3">
                {[
                  { name: "Proteínas", val: 140, max: 160, color: "bg-blue-500", unit: "g" },
                  { name: "Carbohidratos", val: 180, max: 220, color: "bg-amber-500", unit: "g" },
                  { name: "Grasas", val: 60, max: 73, color: "bg-rose-500", unit: "g" },
                ].map((macro) => (
                  <div key={macro.name} className="flex items-center gap-3">
                    <span className="text-xs text-slate-600 dark:text-slate-400 w-24 shrink-0">{macro.name}</span>
                    <div className="flex-1">
                      <div className="h-2 bg-slate-100 dark:bg-slate-700 rounded-full overflow-hidden">
                        <div
                          className={`h-full rounded-full transition-all duration-700 ${macro.color}`}
                          style={{ width: `${(macro.val / macro.max) * 100}%` }}
                        />
                      </div>
                    </div>
                    <span className="text-xs font-semibold text-slate-700 dark:text-slate-300 w-16 text-right">
                      {macro.val}/{macro.max}g
                    </span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Water */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  <Droplets size={18} className="text-blue-500" />
                  Hidratación
                </CardTitle>
                <Badge variant="info">6 / 8 vasos</Badge>
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-center mb-4">
                <span className="text-4xl font-black text-blue-500">1.5L</span>
                <span className="text-slate-400 text-lg"> / 2L</span>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">agua consumida</p>
              </div>
              <div className="grid grid-cols-8 gap-1.5 mb-4">
                {waterGlasses.map((filled, i) => (
                  <div
                    key={i}
                    className={`h-10 rounded-lg flex items-end overflow-hidden border-2 transition-all ${
                      filled
                        ? "border-blue-400 bg-blue-50 dark:bg-blue-950/30"
                        : "border-slate-200 dark:border-slate-700"
                    }`}
                  >
                    {filled && <div className="w-full bg-gradient-to-t from-blue-500 to-blue-400" style={{ height: "70%" }} />}
                  </div>
                ))}
              </div>
              <Progress value={6} max={8} color="bg-gradient-to-r from-blue-400 to-cyan-500" label="Progreso hídrico" />
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-3 text-center">
                💡 Faltan 2 vasos para tu meta diaria
              </p>
            </CardContent>
          </Card>
        </div>
      </motion.div>

      {/* Experience + Achievements */}
      <motion.div custom={7} initial="hidden" animate="visible" variants={fadeUp}>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {/* Level */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Star size={18} className="text-amber-500" />
                Nivel y Experiencia
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-4 mb-4">
                <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-amber-400 to-orange-500 flex items-center justify-center shadow-md">
                  <span className="text-white font-black text-xl">12</span>
                </div>
                <div>
                  <p className="font-bold text-slate-800 dark:text-slate-100">Nivel Intermedio</p>
                  <p className="text-xs text-slate-500 dark:text-slate-400">3,240 / 5,000 XP</p>
                  <p className="text-xs text-indigo-500 dark:text-indigo-400 mt-0.5">Faltan 1,760 XP para Avanzado</p>
                </div>
              </div>
              <Progress value={3240} max={5000} color="bg-gradient-to-r from-amber-400 to-orange-500" size="md" showLabel />
              <div className="grid grid-cols-3 gap-2 mt-4">
                {[
                  { label: "Sesiones", value: "87" },
                  { label: "Volumen", value: "24t" },
                  { label: "Récords", value: "12" },
                ].map((s) => (
                  <div key={s.label} className="text-center p-2 bg-slate-50 dark:bg-slate-700/50 rounded-xl">
                    <p className="font-black text-slate-800 dark:text-slate-100">{s.value}</p>
                    <p className="text-[10px] text-slate-400">{s.label}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Achievements */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  <Award size={18} className="text-purple-500" />
                  Logros recientes
                </CardTitle>
                <button className="text-xs text-indigo-500 hover:text-indigo-600 flex items-center gap-1">
                  Ver todos <ChevronRight size={12} />
                </button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-5 gap-2 mb-4">
                {achievements.map((a) => (
                  <div key={a.label} className="flex flex-col items-center gap-1">
                    <div className={`w-12 h-12 rounded-2xl bg-gradient-to-br ${a.color} flex items-center justify-center shadow-md hover:scale-110 transition-transform`}>
                      <span className="text-xl">{a.icon}</span>
                    </div>
                    <p className="text-[9px] text-slate-500 dark:text-slate-400 text-center leading-tight">{a.label}</p>
                  </div>
                ))}
              </div>
              <div className="bg-indigo-50 dark:bg-indigo-950/30 rounded-xl p-3">
                <p className="text-xs text-slate-600 dark:text-slate-300 font-medium mb-1">🎯 Próximo logro</p>
                <p className="text-sm font-bold text-slate-800 dark:text-slate-100">Guerrero constante</p>
                <p className="text-xs text-slate-500 dark:text-slate-400">Entrena 20 días este mes (12/20)</p>
                <Progress value={12} max={20} color="bg-indigo-500" className="mt-2" />
              </div>
            </CardContent>
          </Card>
        </div>
      </motion.div>

      {/* Weight + Target */}
      <motion.div custom={8} initial="hidden" animate="visible" variants={fadeUp}>
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <Scale size={18} className="text-slate-500" />
                Progreso de peso
              </CardTitle>
              <button onClick={() => onNavigate("progress")} className="text-xs text-indigo-500 hover:text-indigo-600 flex items-center gap-1">
                Ver gráfico <ChevronRight size={12} />
              </button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-6">
              <div className="flex-1">
                <div className="flex items-end gap-3 mb-2">
                  <div>
                    <p className="text-xs text-slate-500 dark:text-slate-400">Actual</p>
                    <p className="text-3xl font-black text-slate-800 dark:text-slate-100">78 <span className="text-base font-normal text-slate-400">kg</span></p>
                  </div>
                  <TrendingUp size={20} className="text-emerald-500 mb-2" />
                  <div>
                    <p className="text-xs text-slate-500 dark:text-slate-400">Objetivo</p>
                    <p className="text-3xl font-black text-emerald-500">75 <span className="text-base font-normal text-slate-400">kg</span></p>
                  </div>
                </div>
                <Progress value={60} max={100} color="bg-gradient-to-r from-indigo-500 to-emerald-500" label="60% hacia la meta" />
              </div>
              <div className="text-center p-4 bg-emerald-50 dark:bg-emerald-950/30 rounded-2xl">
                <p className="text-3xl font-black text-emerald-600">−3</p>
                <p className="text-xs text-emerald-600 font-medium">kg perdidos</p>
                <p className="text-xs text-slate-400 mt-1">vs hace 60 días</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Quick Actions */}
      <motion.div custom={9} initial="hidden" animate="visible" variants={fadeUp}>
        <h3 className="font-bold text-slate-700 dark:text-slate-300 text-sm mb-3 flex items-center gap-2">
          <Zap size={16} className="text-amber-500" />
          Acciones rápidas
        </h3>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
          {[
            { label: "Iniciar entrenamiento", icon: "🏋️", page: "workout", color: "from-indigo-500 to-purple-600" },
            { label: "Registrar comida", icon: "🥗", page: "nutrition", color: "from-emerald-500 to-teal-600" },
            { label: "Registrar peso", icon: "⚖️", page: "progress", color: "from-blue-500 to-cyan-600" },
            { label: "Ver rutinas", icon: "📋", page: "routines", color: "from-amber-500 to-orange-600" },
          ].map((action) => (
            <button
              key={action.label}
              onClick={() => onNavigate(action.page)}
              className={`p-4 rounded-2xl bg-gradient-to-br ${action.color} text-white text-left hover:scale-[1.02] hover:shadow-lg transition-all duration-200 btn-press`}
            >
              <span className="text-2xl block mb-2">{action.icon}</span>
              <p className="text-xs font-semibold leading-tight">{action.label}</p>
            </button>
          ))}
        </div>
      </motion.div>
    </div>
  );
};
