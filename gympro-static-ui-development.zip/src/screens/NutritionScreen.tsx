import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Plus, Search, X, Camera, Barcode, Droplets, ChevronDown, ChevronUp } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/Card";
import { Badge } from "@/components/ui/Badge";
import { Progress } from "@/components/ui/Progress";
import { Modal } from "@/components/ui/Modal";

const meals = [
  {
    id: "breakfast", name: "Desayuno", emoji: "🌅", time: "08:30",
    foods: [
      { name: "Avena con leche", kcal: 320, protein: 14, carbs: 52, fat: 6, qty: "100g" },
      { name: "Plátano", kcal: 89, protein: 1, carbs: 23, fat: 0, qty: "1 ud" },
      { name: "Huevos revueltos", kcal: 218, protein: 18, carbs: 2, fat: 15, qty: "3 uds" },
    ]
  },
  {
    id: "lunch", name: "Almuerzo", emoji: "☀️", time: "13:00",
    foods: [
      { name: "Arroz integral", kcal: 216, protein: 5, carbs: 45, fat: 2, qty: "150g" },
      { name: "Pechuga de pollo", kcal: 248, protein: 46, carbs: 0, fat: 5, qty: "200g" },
      { name: "Brócoli al vapor", kcal: 55, protein: 4, carbs: 11, fat: 0, qty: "200g" },
    ]
  },
  {
    id: "snack", name: "Merienda", emoji: "🍎", time: "16:30",
    foods: [
      { name: "Proteína en polvo", kcal: 120, protein: 24, carbs: 3, fat: 1, qty: "1 medida" },
      { name: "Manzana", kcal: 72, protein: 0, carbs: 19, fat: 0, qty: "1 ud" },
    ]
  },
  {
    id: "dinner", name: "Cena", emoji: "🌙", time: "20:00",
    foods: [
      { name: "Salmón a la plancha", kcal: 280, protein: 39, carbs: 0, fat: 14, qty: "200g" },
      { name: "Patata cocida", kcal: 130, protein: 3, carbs: 30, fat: 0, qty: "150g" },
      { name: "Ensalada verde", kcal: 25, protein: 2, carbs: 4, fat: 0, qty: "100g" },
    ]
  },
];

const foodDatabase = [
  { name: "Pechuga de pollo", kcal: 124, protein: 23, carbs: 0, fat: 3 },
  { name: "Arroz blanco cocido", kcal: 130, protein: 3, carbs: 28, fat: 0 },
  { name: "Avena", kcal: 389, protein: 17, carbs: 66, fat: 7 },
  { name: "Huevo entero", kcal: 73, protein: 6, carbs: 0, fat: 5 },
  { name: "Leche semidesnatada", kcal: 46, protein: 3, carbs: 5, fat: 2 },
  { name: "Plátano", kcal: 89, protein: 1, carbs: 23, fat: 0 },
  { name: "Salmón", kcal: 208, protein: 20, carbs: 0, fat: 13 },
  { name: "Brócoli", kcal: 34, protein: 3, carbs: 7, fat: 0 },
  { name: "Almendras", kcal: 579, protein: 21, carbs: 22, fat: 50 },
  { name: "Yogur griego", kcal: 59, protein: 10, carbs: 4, fat: 0 },
  { name: "Queso cottage", kcal: 98, protein: 11, carbs: 3, fat: 4 },
  { name: "Quinoa cocida", kcal: 120, protein: 4, carbs: 21, fat: 2 },
];

const waterHistory = [
  { day: "L", amount: 2.0, goal: 2.0 },
  { day: "M", amount: 1.5, goal: 2.0 },
  { day: "X", amount: 1.8, goal: 2.0 },
  { day: "J", amount: 2.0, goal: 2.0 },
  { day: "V", amount: 1.2, goal: 2.0 },
  { day: "S", amount: 2.2, goal: 2.0 },
  { day: "D", amount: 1.5, goal: 2.0 },
];

export const NutritionScreen: React.FC = () => {
  const [expandedMeal, setExpandedMeal] = useState<string | null>("breakfast");
  const [showAddFood, setShowAddFood] = useState(false);
  const [addingToMeal, setAddingToMeal] = useState<string>("");
  const [foodSearch, setFoodSearch] = useState("");
  const [addedFoods, setAddedFoods] = useState<string[]>([]);

  const totalKcal = meals.reduce((sum, m) => sum + m.foods.reduce((s, f) => s + f.kcal, 0), 0);
  const totalProtein = meals.reduce((sum, m) => sum + m.foods.reduce((s, f) => s + f.protein, 0), 0);
  const totalCarbs = meals.reduce((sum, m) => sum + m.foods.reduce((s, f) => s + f.carbs, 0), 0);
  const totalFat = meals.reduce((sum, m) => sum + m.foods.reduce((s, f) => s + f.fat, 0), 0);

  const filteredFoods = foodDatabase.filter(f =>
    f.name.toLowerCase().includes(foodSearch.toLowerCase())
  );

  return (
    <div className="space-y-5">
      {/* Daily summary */}
      <Card className="bg-gradient-to-br from-emerald-500 to-teal-600 border-0">
        <CardContent className="p-5 text-white">
          <div className="flex items-center justify-between mb-4">
            <div>
              <p className="text-emerald-100 text-sm">Calorías de hoy</p>
              <div className="flex items-end gap-2">
                <span className="text-5xl font-black">{totalKcal}</span>
                <span className="text-emerald-200 text-lg mb-1">/ 2,200 kcal</span>
              </div>
            </div>
            <div className="text-right">
              <p className="text-emerald-100 text-sm">Restantes</p>
              <p className="text-3xl font-black">{2200 - totalKcal}</p>
              <p className="text-emerald-200 text-xs">kcal</p>
            </div>
          </div>
          <div className="h-3 bg-white/20 rounded-full overflow-hidden mb-4">
            <div
              className="h-full bg-white rounded-full transition-all duration-700"
              style={{ width: `${Math.min(100, (totalKcal / 2200) * 100)}%` }}
            />
          </div>
          {/* Macros row */}
          <div className="grid grid-cols-3 gap-3">
            {[
              { name: "Proteínas", val: totalProtein, goal: 160, color: "bg-blue-400" },
              { name: "Carbos", val: totalCarbs, goal: 220, color: "bg-amber-400" },
              { name: "Grasas", val: totalFat, goal: 73, color: "bg-rose-400" },
            ].map(m => (
              <div key={m.name} className="bg-white/10 rounded-xl p-3">
                <p className="text-xs text-emerald-100 mb-1">{m.name}</p>
                <p className="font-black text-lg">{m.val}g</p>
                <p className="text-xs text-emerald-200">/ {m.goal}g</p>
                <div className="mt-1.5 h-1.5 bg-white/20 rounded-full overflow-hidden">
                  <div className={`h-full ${m.color} rounded-full`} style={{ width: `${Math.min(100, (m.val / m.goal) * 100)}%` }} />
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Scan / Photo buttons */}
      <div className="grid grid-cols-2 gap-3">
        <button className="flex items-center justify-center gap-2 py-3 border-2 border-dashed border-slate-200 dark:border-slate-700 rounded-xl text-slate-500 dark:text-slate-400 text-sm font-medium hover:border-indigo-300 dark:hover:border-indigo-700 hover:text-indigo-500 transition-all">
          <Barcode size={18} />
          Escanear código
        </button>
        <button className="flex items-center justify-center gap-2 py-3 border-2 border-dashed border-slate-200 dark:border-slate-700 rounded-xl text-slate-500 dark:text-slate-400 text-sm font-medium hover:border-indigo-300 dark:hover:border-indigo-700 hover:text-indigo-500 transition-all">
          <Camera size={18} />
          Foto del plato
        </button>
      </div>

      {/* Meals */}
      <div className="space-y-3">
        {meals.map((meal) => {
          const mealKcal = meal.foods.reduce((s, f) => s + f.kcal, 0);
          const isExpanded = expandedMeal === meal.id;
          return (
            <Card key={meal.id}>
              <button
                onClick={() => setExpandedMeal(isExpanded ? null : meal.id)}
                className="w-full p-4 flex items-center gap-3 hover:bg-slate-50 dark:hover:bg-slate-700/30 transition-colors rounded-2xl text-left"
              >
                <span className="text-2xl">{meal.emoji}</span>
                <div className="flex-1">
                  <p className="font-bold text-slate-800 dark:text-slate-100">{meal.name}</p>
                  <p className="text-xs text-slate-500 dark:text-slate-400">{meal.time} · {meal.foods.length} alimentos</p>
                </div>
                <div className="text-right">
                  <p className="font-bold text-slate-700 dark:text-slate-200">{mealKcal} kcal</p>
                </div>
                {isExpanded ? <ChevronUp size={16} className="text-slate-400 ml-1" /> : <ChevronDown size={16} className="text-slate-400 ml-1" />}
              </button>

              <AnimatePresence>
                {isExpanded && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: "auto", opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    className="overflow-hidden"
                  >
                    <div className="px-4 pb-4 space-y-2">
                      {meal.foods.map((food) => (
                        <div key={food.name} className="flex items-center gap-3 p-2.5 bg-slate-50 dark:bg-slate-700/50 rounded-xl group">
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-medium text-slate-700 dark:text-slate-200 truncate">{food.name}</p>
                            <p className="text-xs text-slate-400 dark:text-slate-500">{food.qty}</p>
                          </div>
                          <div className="flex items-center gap-3 text-xs text-slate-500 dark:text-slate-400 shrink-0">
                            <span className="font-semibold text-slate-700 dark:text-slate-200">{food.kcal} kcal</span>
                            <span className="text-blue-500">{food.protein}P</span>
                            <span className="text-amber-500">{food.carbs}C</span>
                            <span className="text-rose-500">{food.fat}G</span>
                          </div>
                          <button className="opacity-0 group-hover:opacity-100 p-1 text-red-400 hover:text-red-600 transition-all">
                            <X size={14} />
                          </button>
                        </div>
                      ))}

                      {/* Added foods */}
                      {addedFoods.filter(f => f.startsWith(meal.id)).map(f => (
                        <div key={f} className="flex items-center gap-3 p-2.5 bg-indigo-50 dark:bg-indigo-950/30 rounded-xl border border-indigo-100 dark:border-indigo-900/40">
                          <div className="flex-1">
                            <p className="text-sm font-medium text-indigo-700 dark:text-indigo-300">{f.split(":")[1]}</p>
                            <p className="text-xs text-indigo-400">100g · Añadido ahora</p>
                          </div>
                          <Badge variant="info" className="text-xs">Nuevo</Badge>
                        </div>
                      ))}

                      <button
                        onClick={() => { setAddingToMeal(meal.id); setShowAddFood(true); }}
                        className="w-full py-2.5 flex items-center justify-center gap-2 border-2 border-dashed border-slate-200 dark:border-slate-700 rounded-xl text-slate-500 dark:text-slate-400 text-sm hover:border-indigo-300 hover:text-indigo-500 transition-all"
                      >
                        <Plus size={15} />
                        Añadir alimento
                      </button>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </Card>
          );
        })}
      </div>

      {/* Water section */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Droplets size={18} className="text-blue-500" />
            Hidratación diaria
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between mb-3">
            <div>
              <p className="text-3xl font-black text-blue-500">1.5 L</p>
              <p className="text-xs text-slate-500 dark:text-slate-400">de 2 L diarios</p>
            </div>
            <div className="grid grid-cols-4 gap-1.5">
              {[...Array(8)].map((_, i) => (
                <button key={i} className={`w-8 h-10 rounded-lg flex items-end overflow-hidden border-2 transition-all ${
                  i < 6
                    ? "border-blue-400 bg-blue-50 dark:bg-blue-950/30"
                    : "border-slate-200 dark:border-slate-700 hover:border-blue-300"
                }`}>
                  {i < 6 && <div className="w-full bg-gradient-to-t from-blue-500 to-blue-400" style={{ height: "70%" }} />}
                </button>
              ))}
            </div>
          </div>
          <Progress value={1.5} max={2} color="bg-gradient-to-r from-blue-400 to-cyan-500" />

          {/* Weekly mini chart */}
          <div className="mt-4">
            <p className="text-xs font-semibold text-slate-600 dark:text-slate-400 mb-2">Historial semanal</p>
            <div className="flex items-end gap-2 h-16">
              {waterHistory.map((day) => (
                <div key={day.day} className="flex-1 flex flex-col items-center gap-1">
                  <div className="flex-1 w-full flex items-end">
                    <div
                      className={`w-full rounded-t-lg transition-all duration-700 ${
                        day.amount >= day.goal ? "bg-emerald-500" : "bg-blue-400"
                      }`}
                      style={{ height: `${(day.amount / 2.5) * 100}%` }}
                    />
                  </div>
                  <span className="text-[10px] text-slate-400">{day.day}</span>
                </div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Add food modal */}
      <Modal
        open={showAddFood}
        onClose={() => { setShowAddFood(false); setFoodSearch(""); }}
        title="Añadir alimento"
        size="md"
      >
        <div className="space-y-4">
          {/* Search */}
          <div className="relative">
            <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              placeholder="Buscar alimento..."
              value={foodSearch}
              onChange={e => setFoodSearch(e.target.value)}
              autoFocus
              className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-600 bg-white dark:bg-slate-700/50 text-slate-800 dark:text-slate-100 text-sm focus:outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20"
            />
          </div>

          {/* Scan buttons */}
          <div className="grid grid-cols-2 gap-2">
            <button className="flex items-center justify-center gap-2 py-2.5 border border-slate-200 dark:border-slate-600 rounded-xl text-slate-500 dark:text-slate-400 text-xs hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors">
              <Barcode size={14} />
              Escanear código de barras
            </button>
            <button className="flex items-center justify-center gap-2 py-2.5 border border-slate-200 dark:border-slate-600 rounded-xl text-slate-500 dark:text-slate-400 text-xs hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors">
              <Camera size={14} />
              Reconocer foto
            </button>
          </div>

          {/* Food list */}
          <div className="space-y-1 max-h-64 overflow-y-auto no-scrollbar">
            {filteredFoods.map((food) => (
              <button
                key={food.name}
                onClick={() => {
                  setAddedFoods(prev => [...prev, `${addingToMeal}:${food.name}`]);
                  setShowAddFood(false);
                  setFoodSearch("");
                }}
                className="w-full flex items-center justify-between p-3 hover:bg-indigo-50 dark:hover:bg-indigo-950/30 rounded-xl transition-colors group"
              >
                <div className="text-left">
                  <p className="text-sm font-medium text-slate-700 dark:text-slate-200">{food.name}</p>
                  <p className="text-xs text-slate-400">por 100g</p>
                </div>
                <div className="text-right">
                  <p className="text-sm font-bold text-slate-700 dark:text-slate-200">{food.kcal} kcal</p>
                  <p className="text-xs text-slate-400">{food.protein}P · {food.carbs}C · {food.fat}G</p>
                </div>
              </button>
            ))}
          </div>
        </div>
      </Modal>
    </div>
  );
};
