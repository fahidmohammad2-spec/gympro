import React, { useState } from "react";
import {
  Camera, Edit3, Moon, Sun, Settings, LogOut, Trash2,
  Shield, Bell, HelpCircle, ChevronRight, Award
} from "lucide-react";
import { Card, CardContent } from "@/components/ui/Card";
import { Badge } from "@/components/ui/Badge";
import { Progress } from "@/components/ui/Progress";
import { Modal } from "@/components/ui/Modal";

interface ProfileScreenProps {
  darkMode: boolean;
  onToggleDark: () => void;
  onNavigate: (page: string) => void;
}

const stats = [
  { label: "Sesiones", value: "87", icon: "🏋️" },
  { label: "Días racha", value: "12 🔥", icon: "" },
  { label: "Volumen total", value: "24t", icon: "📦" },
  { label: "Récords", value: "12 🏆", icon: "" },
];

const achievements = [
  { emoji: "🏆", label: "Primer mes", earned: true },
  { emoji: "🔥", label: "Racha 10", earned: true },
  { emoji: "💪", label: "100kg Press", earned: true },
  { emoji: "⚡", label: "50 sesiones", earned: true },
  { emoji: "🎯", label: "Meta semanal", earned: true },
  { emoji: "🌟", label: "Racha 30", earned: false },
  { emoji: "🦁", label: "200 sesiones", earned: false },
  { emoji: "💎", label: "1 año activo", earned: false },
];

const menuItems = [
  { icon: <Edit3 size={18} />, label: "Editar perfil", action: "edit", color: "text-indigo-500" },
  { icon: <Bell size={18} />, label: "Notificaciones", action: "notifs", color: "text-blue-500" },
  { icon: <Shield size={18} />, label: "Privacidad y seguridad", action: "privacy", color: "text-purple-500" },
  { icon: <HelpCircle size={18} />, label: "Ayuda y soporte", action: "help", color: "text-emerald-500" },
  { icon: <Settings size={18} />, label: "Configuración", action: "settings", color: "text-slate-500" },
];

export const ProfileScreen: React.FC<ProfileScreenProps> = ({ darkMode, onToggleDark, onNavigate }) => {
  const [showEditModal, setShowEditModal] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);

  return (
    <div className="space-y-5 pb-6">
      {/* Profile hero */}
      <div className="relative bg-gradient-to-br from-indigo-600 via-purple-600 to-pink-600 rounded-2xl pt-8 pb-6 px-6 text-white overflow-hidden">
        <div className="absolute top-0 right-0 w-48 h-48 bg-white/10 rounded-full -translate-y-1/2 translate-x-1/4" />
        <div className="absolute bottom-0 left-0 w-32 h-32 bg-white/5 rounded-full translate-y-1/2 -translate-x-1/4" />

        <div className="relative flex flex-col items-center text-center">
          {/* Avatar */}
          <div className="relative mb-4">
            <div className="w-24 h-24 rounded-full bg-gradient-to-br from-indigo-300 to-purple-400 flex items-center justify-center text-white font-black text-2xl border-4 border-white/30 shadow-xl">
              CA
            </div>
            <button className="absolute -bottom-1 -right-1 w-8 h-8 rounded-full bg-white flex items-center justify-center shadow-lg hover:scale-110 transition-transform">
              <Camera size={14} className="text-indigo-600" />
            </button>
          </div>

          <h2 className="text-2xl font-black">Carlos Andrés García</h2>
          <p className="text-indigo-200 text-sm">@carlosandres · Miembro desde Nov 2023</p>
          <div className="flex items-center gap-2 mt-2">
            <Badge className="bg-white/20 text-white border-0">⭐ Nivel Intermedio</Badge>
            <Badge className="bg-white/20 text-white border-0">🔥 12 días</Badge>
          </div>

          {/* Edit button */}
          <button
            onClick={() => setShowEditModal(true)}
            className="mt-4 flex items-center gap-2 px-5 py-2 bg-white/20 hover:bg-white/30 backdrop-blur-sm border border-white/20 rounded-xl text-sm font-semibold transition-all"
          >
            <Edit3 size={14} />
            Editar perfil
          </button>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-4 gap-2">
        {stats.map((s) => (
          <Card key={s.label}>
            <CardContent className="p-3 text-center">
              <p className="font-black text-lg text-slate-800 dark:text-slate-100">{s.value}</p>
              <p className="text-[10px] text-slate-400 leading-tight">{s.label}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Level progress */}
      <Card>
        <CardContent className="p-4">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-400 to-orange-500 flex items-center justify-center shadow-md">
                <span className="text-white font-black text-sm">12</span>
              </div>
              <div>
                <p className="font-bold text-slate-800 dark:text-slate-100">Nivel Intermedio</p>
                <p className="text-xs text-slate-500 dark:text-slate-400">3,240 / 5,000 XP</p>
              </div>
            </div>
            <Badge variant="warning">70%</Badge>
          </div>
          <Progress value={3240} max={5000} color="bg-gradient-to-r from-amber-400 to-orange-500" size="md" />
          <p className="text-xs text-slate-400 mt-2">Faltan 1,760 XP para Nivel Avanzado</p>
        </CardContent>
      </Card>

      {/* Achievements */}
      <Card>
        <CardContent className="p-4">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2">
              <Award size={18} className="text-purple-500" />
              Logros ({achievements.filter(a => a.earned).length}/{achievements.length})
            </h3>
            <button className="text-xs text-indigo-500 hover:text-indigo-600 flex items-center gap-1">
              Ver todos <ChevronRight size={12} />
            </button>
          </div>
          <div className="grid grid-cols-4 gap-3">
            {achievements.map((a) => (
              <div key={a.label} className="flex flex-col items-center gap-1">
                <div className={`w-12 h-12 rounded-2xl flex items-center justify-center text-2xl transition-all hover:scale-105 ${
                  a.earned
                    ? "bg-gradient-to-br from-amber-100 to-yellow-200 dark:from-amber-900/40 dark:to-yellow-900/40 shadow-md"
                    : "bg-slate-100 dark:bg-slate-700/50 opacity-40 grayscale"
                }`}>
                  {a.emoji}
                </div>
                <p className="text-[9px] text-slate-500 dark:text-slate-400 text-center leading-tight">{a.label}</p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Settings menu */}
      <Card>
        <CardContent className="p-2">
          {/* Dark mode toggle */}
          <div className="flex items-center gap-3 px-3 py-3 rounded-xl hover:bg-slate-50 dark:hover:bg-slate-700/50 transition-colors">
            <div className="w-9 h-9 rounded-xl bg-indigo-50 dark:bg-indigo-950/40 flex items-center justify-center">
              {darkMode ? <Sun size={18} className="text-amber-500" /> : <Moon size={18} className="text-indigo-500" />}
            </div>
            <div className="flex-1">
              <p className="text-sm font-semibold text-slate-700 dark:text-slate-200">
                {darkMode ? "Modo claro" : "Modo oscuro"}
              </p>
              <p className="text-xs text-slate-400">Cambiar apariencia</p>
            </div>
            <button
              onClick={onToggleDark}
              className={`relative w-12 h-6 rounded-full transition-all duration-300 ${darkMode ? "bg-indigo-600" : "bg-slate-200 dark:bg-slate-700"}`}
            >
              <div className={`absolute top-1 w-4 h-4 rounded-full bg-white shadow-sm transition-all duration-300 ${darkMode ? "left-7" : "left-1"}`} />
            </button>
          </div>

          <div className="h-px bg-slate-100 dark:bg-slate-700 mx-3" />

          {menuItems.map((item) => (
            <button key={item.label} className="w-full flex items-center gap-3 px-3 py-3 rounded-xl hover:bg-slate-50 dark:hover:bg-slate-700/50 transition-colors text-left">
              <div className="w-9 h-9 rounded-xl bg-slate-50 dark:bg-slate-700/50 flex items-center justify-center">
                <span className={item.color}>{item.icon}</span>
              </div>
              <span className="flex-1 text-sm font-medium text-slate-700 dark:text-slate-200">{item.label}</span>
              <ChevronRight size={16} className="text-slate-300 dark:text-slate-600" />
            </button>
          ))}
        </CardContent>
      </Card>

      {/* Danger zone */}
      <Card className="border-red-100 dark:border-red-900/40">
        <CardContent className="p-2">
          <button
            onClick={() => onNavigate("auth")}
            className="w-full flex items-center gap-3 px-3 py-3 rounded-xl hover:bg-red-50 dark:hover:bg-red-950/30 transition-colors text-left"
          >
            <div className="w-9 h-9 rounded-xl bg-red-50 dark:bg-red-950/40 flex items-center justify-center">
              <LogOut size={18} className="text-red-500" />
            </div>
            <span className="flex-1 text-sm font-medium text-red-500">Cerrar sesión</span>
          </button>
          <button
            onClick={() => setShowDeleteModal(true)}
            className="w-full flex items-center gap-3 px-3 py-3 rounded-xl hover:bg-red-50 dark:hover:bg-red-950/30 transition-colors text-left"
          >
            <div className="w-9 h-9 rounded-xl bg-red-50 dark:bg-red-950/40 flex items-center justify-center">
              <Trash2 size={18} className="text-red-500" />
            </div>
            <span className="flex-1 text-sm font-medium text-red-500">Eliminar cuenta</span>
          </button>
        </CardContent>
      </Card>

      {/* Edit profile modal */}
      <Modal open={showEditModal} onClose={() => setShowEditModal(false)} title="Editar perfil" size="lg">
        <div className="space-y-4">
          {/* Avatar */}
          <div className="flex flex-col items-center gap-2">
            <div className="relative">
              <div className="w-20 h-20 rounded-full bg-gradient-to-br from-indigo-400 to-purple-500 flex items-center justify-center text-white font-black text-xl">CA</div>
              <button className="absolute -bottom-1 -right-1 w-7 h-7 rounded-full bg-indigo-600 flex items-center justify-center">
                <Camera size={12} className="text-white" />
              </button>
            </div>
            <button className="text-xs text-indigo-500 hover:text-indigo-600 font-medium">Cambiar foto de perfil</button>
          </div>

          <div className="grid grid-cols-2 gap-3">
            {[
              { label: "Nombre", default: "Carlos Andrés" },
              { label: "Apellidos", default: "García López" },
            ].map(f => (
              <div key={f.label}>
                <label className="text-xs font-medium text-slate-600 dark:text-slate-400 mb-1 block">{f.label}</label>
                <input defaultValue={f.default} className="w-full px-3 py-2.5 rounded-xl border border-slate-200 dark:border-slate-600 bg-white dark:bg-slate-700/50 text-slate-800 dark:text-slate-100 text-sm focus:outline-none focus:border-indigo-500" />
              </div>
            ))}
          </div>

          {[
            { label: "Email", default: "carlos@example.com", type: "email" },
            { label: "Teléfono", default: "+34 612 345 678", type: "tel" },
          ].map(f => (
            <div key={f.label}>
              <label className="text-xs font-medium text-slate-600 dark:text-slate-400 mb-1 block">{f.label}</label>
              <input type={f.type} defaultValue={f.default} className="w-full px-3 py-2.5 rounded-xl border border-slate-200 dark:border-slate-600 bg-white dark:bg-slate-700/50 text-slate-800 dark:text-slate-100 text-sm focus:outline-none focus:border-indigo-500" />
            </div>
          ))}

          <div className="grid grid-cols-2 gap-3">
            {[
              { label: "Peso (kg)", default: "78" },
              { label: "Altura (cm)", default: "178" },
              { label: "Edad", default: "29" },
            ].map(f => (
              <div key={f.label}>
                <label className="text-xs font-medium text-slate-600 dark:text-slate-400 mb-1 block">{f.label}</label>
                <input type="number" defaultValue={f.default} className="w-full px-3 py-2.5 rounded-xl border border-slate-200 dark:border-slate-600 bg-white dark:bg-slate-700/50 text-slate-800 dark:text-slate-100 text-sm focus:outline-none focus:border-indigo-500" />
              </div>
            ))}
            <div>
              <label className="text-xs font-medium text-slate-600 dark:text-slate-400 mb-1 block">Nivel</label>
              <select className="w-full px-3 py-2.5 rounded-xl border border-slate-200 dark:border-slate-600 bg-white dark:bg-slate-700/50 text-slate-800 dark:text-slate-100 text-sm focus:outline-none focus:border-indigo-500">
                <option>Principiante</option>
                <option selected>Intermedio</option>
                <option>Avanzado</option>
              </select>
            </div>
          </div>

          <div className="flex gap-3 pt-2 border-t border-slate-100 dark:border-slate-700">
            <button onClick={() => setShowEditModal(false)} className="flex-1 py-3 border-2 border-slate-200 dark:border-slate-700 rounded-xl text-slate-600 dark:text-slate-300 font-semibold hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors">
              Cancelar
            </button>
            <button onClick={() => setShowEditModal(false)} className="flex-1 py-3 bg-indigo-600 text-white font-bold rounded-xl hover:bg-indigo-700 transition-colors">
              Guardar cambios
            </button>
          </div>
        </div>
      </Modal>

      {/* Delete account modal */}
      <Modal open={showDeleteModal} onClose={() => setShowDeleteModal(false)} title="Eliminar cuenta" size="sm">
        <div className="space-y-4 text-center">
          <div className="w-16 h-16 rounded-full bg-red-100 dark:bg-red-950/40 flex items-center justify-center mx-auto">
            <Trash2 size={28} className="text-red-500" />
          </div>
          <p className="text-slate-600 dark:text-slate-400 text-sm leading-relaxed">
            ¿Estás seguro de que quieres eliminar tu cuenta? Esta acción es <strong className="text-red-500">irreversible</strong> y perderás todos tus datos, historial y logros.
          </p>
          <div className="flex gap-3">
            <button onClick={() => setShowDeleteModal(false)} className="flex-1 py-3 border-2 border-slate-200 dark:border-slate-700 rounded-xl text-slate-600 dark:text-slate-300 font-semibold hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors">
              Cancelar
            </button>
            <button onClick={() => setShowDeleteModal(false)} className="flex-1 py-3 bg-red-500 text-white font-bold rounded-xl hover:bg-red-600 transition-colors">
              Eliminar
            </button>
          </div>
        </div>
      </Modal>
    </div>
  );
};
