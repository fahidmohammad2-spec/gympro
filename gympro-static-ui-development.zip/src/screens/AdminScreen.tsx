import React, { useState } from "react";
import { motion } from "framer-motion";
import { Users, Dumbbell, BarChart2, Trash2, Edit2, Plus, Search, Shield, TrendingUp, Activity } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/Card";
import { Badge } from "@/components/ui/Badge";

const adminStats = [
  { icon: <Users size={20} className="text-indigo-500" />, label: "Usuarios totales", value: "12,847", change: "+234 este mes", bg: "bg-indigo-50 dark:bg-indigo-950/30" },
  { icon: <Dumbbell size={20} className="text-purple-500" />, label: "Ejercicios", value: "512", change: "+8 esta semana", bg: "bg-purple-50 dark:bg-purple-950/30" },
  { icon: <Activity size={20} className="text-emerald-500" />, label: "Sesiones hoy", value: "3,241", change: "+12% vs ayer", bg: "bg-emerald-50 dark:bg-emerald-950/30" },
  { icon: <TrendingUp size={20} className="text-amber-500" />, label: "Retención 30d", value: "78.4%", change: "+2.1%", bg: "bg-amber-50 dark:bg-amber-950/30" },
];

const usersData = [
  { id: 1, name: "María García", email: "maria@example.com", level: "Avanzado", status: "Activo", joined: "Nov 2023", sessions: 145 },
  { id: 2, name: "Carlos Andrés", email: "carlos@example.com", level: "Intermedio", status: "Activo", joined: "Oct 2023", sessions: 87 },
  { id: 3, name: "Javier López", email: "javier@example.com", level: "Principiante", status: "Activo", joined: "Dic 2023", sessions: 23 },
  { id: 4, name: "Ana Martínez", email: "ana@example.com", level: "Avanzado", status: "Activo", joined: "Sep 2023", sessions: 203 },
  { id: 5, name: "Pedro Ruiz", email: "pedro@example.com", level: "Intermedio", status: "Inactivo", joined: "Nov 2023", sessions: 45 },
  { id: 6, name: "Laura Sánchez", email: "laura@example.com", level: "Intermedio", status: "Activo", joined: "Ene 2024", sessions: 67 },
];

const exercisesData = [
  { id: 1, name: "Press de Banca", muscle: "Pecho", level: "Intermedio", equipment: "Barra", status: "Publicado", uses: 8420 },
  { id: 2, name: "Sentadilla", muscle: "Piernas", level: "Principiante", equipment: "Barra", status: "Publicado", uses: 12350 },
  { id: 3, name: "Peso Muerto", muscle: "Espalda", level: "Avanzado", equipment: "Barra", status: "Publicado", uses: 9870 },
  { id: 4, name: "Dominadas", muscle: "Espalda", level: "Intermedio", equipment: "Barra fija", status: "Publicado", uses: 7230 },
  { id: 5, name: "Press Militar", muscle: "Hombros", level: "Intermedio", equipment: "Barra", status: "Borrador", uses: 0 },
  { id: 6, name: "Hip Thrust", muscle: "Glúteos", level: "Intermedio", equipment: "Barra", status: "Publicado", uses: 5640 },
];

export const AdminScreen: React.FC = () => {
  const [activeTab, setActiveTab] = useState<"overview" | "users" | "exercises">("overview");
  const [search, setSearch] = useState("");

  const filteredUsers = usersData.filter(u =>
    u.name.toLowerCase().includes(search.toLowerCase()) ||
    u.email.toLowerCase().includes(search.toLowerCase())
  );

  const filteredExercises = exercisesData.filter(e =>
    e.name.toLowerCase().includes(search.toLowerCase()) ||
    e.muscle.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-5">
      {/* Admin header */}
      <div className="flex items-center gap-3 p-4 bg-gradient-to-r from-slate-800 to-slate-900 rounded-2xl">
        <div className="w-10 h-10 rounded-xl bg-red-500/20 flex items-center justify-center">
          <Shield size={20} className="text-red-400" />
        </div>
        <div>
          <p className="font-bold text-white">Panel de Administración</p>
          <p className="text-xs text-slate-400">Acceso restringido · Admin: Carlos Andrés</p>
        </div>
        <Badge variant="danger" className="ml-auto">Admin</Badge>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 bg-slate-100 dark:bg-slate-800 p-1 rounded-xl">
        {[
          { id: "overview", label: "Resumen", icon: <BarChart2 size={14} /> },
          { id: "users", label: "Usuarios", icon: <Users size={14} /> },
          { id: "exercises", label: "Ejercicios", icon: <Dumbbell size={14} /> },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as typeof activeTab)}
            className={`flex-1 flex items-center justify-center gap-1.5 py-2 text-sm font-semibold rounded-lg transition-all duration-200 ${
              activeTab === tab.id
                ? "bg-white dark:bg-slate-700 text-indigo-600 dark:text-indigo-400 shadow-sm"
                : "text-slate-500 dark:text-slate-400"
            }`}
          >
            {tab.icon}
            {tab.label}
          </button>
        ))}
      </div>

      {/* OVERVIEW */}
      {activeTab === "overview" && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-5">
          {/* Stats grid */}
          <div className="grid grid-cols-2 gap-3">
            {adminStats.map((stat, i) => (
              <motion.div key={stat.label} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.07 }}>
                <Card>
                  <CardContent className="p-4">
                    <div className={`w-10 h-10 rounded-xl ${stat.bg} flex items-center justify-center mb-3`}>
                      {stat.icon}
                    </div>
                    <p className="text-2xl font-black text-slate-800 dark:text-slate-100">{stat.value}</p>
                    <p className="text-xs font-medium text-slate-600 dark:text-slate-400">{stat.label}</p>
                    <p className="text-xs text-emerald-500 mt-0.5">{stat.change}</p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>

          {/* Recent activity */}
          <Card>
            <CardHeader>
              <CardTitle>Actividad reciente</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {[
                  { action: "Nuevo usuario registrado", detail: "Ana Ruiz (ana.ruiz@gmail.com)", time: "Hace 5 min", color: "bg-emerald-500" },
                  { action: "Sesión completada", detail: "Carlos Andrés · Rutina de Pierna", time: "Hace 12 min", color: "bg-blue-500" },
                  { action: "Ejercicio creado", detail: "Press Suizo · Pecho (Admin)", time: "Hace 30 min", color: "bg-purple-500" },
                  { action: "Reporte de usuario", detail: "Contenido inapropiado en feed", time: "Hace 1h", color: "bg-red-500" },
                  { action: "Meta alcanzada", detail: "María García · 200 sesiones", time: "Hace 2h", color: "bg-amber-500" },
                ].map((a, i) => (
                  <div key={i} className="flex items-center gap-3">
                    <div className={`w-2 h-2 rounded-full ${a.color} shrink-0`} />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-slate-700 dark:text-slate-300">{a.action}</p>
                      <p className="text-xs text-slate-400 truncate">{a.detail}</p>
                    </div>
                    <span className="text-xs text-slate-400 shrink-0">{a.time}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Quick metrics */}
          <div className="grid grid-cols-3 gap-3">
            {[
              { label: "Rutinas creadas", value: "34,210", icon: "📋" },
              { label: "Logros desbloqueados", value: "89,450", icon: "🏆" },
              { label: "Notificaciones enviadas", value: "12,040", icon: "🔔" },
            ].map(m => (
              <Card key={m.label}>
                <CardContent className="p-3 text-center">
                  <span className="text-2xl">{m.icon}</span>
                  <p className="font-black text-slate-800 dark:text-slate-100 mt-1">{m.value}</p>
                  <p className="text-[10px] text-slate-400 leading-tight">{m.label}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </motion.div>
      )}

      {/* USERS */}
      {activeTab === "users" && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-4">
          {/* Search + Add */}
          <div className="flex gap-2">
            <div className="relative flex-1">
              <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                placeholder="Buscar usuarios..."
                value={search}
                onChange={e => setSearch(e.target.value)}
                className="w-full pl-9 pr-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800/50 text-slate-800 dark:text-slate-100 placeholder:text-slate-400 text-sm focus:outline-none focus:border-indigo-500"
              />
            </div>
            <button className="flex items-center gap-1.5 px-4 py-2.5 bg-indigo-600 text-white rounded-xl text-sm font-bold hover:bg-indigo-700 transition-colors shrink-0">
              <Plus size={16} /> Añadir
            </button>
          </div>

          {/* Users table */}
          <Card>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="border-b border-slate-100 dark:border-slate-700">
                  <tr className="text-xs text-slate-400 dark:text-slate-500 uppercase">
                    <th className="text-left p-4 font-semibold">Usuario</th>
                    <th className="text-left p-4 font-semibold hidden md:table-cell">Nivel</th>
                    <th className="text-left p-4 font-semibold hidden lg:table-cell">Sesiones</th>
                    <th className="text-left p-4 font-semibold">Estado</th>
                    <th className="text-right p-4 font-semibold">Acciones</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-50 dark:divide-slate-700/50">
                  {filteredUsers.map((user) => (
                    <tr key={user.id} className="hover:bg-slate-50 dark:hover:bg-slate-700/30 transition-colors">
                      <td className="p-4">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-full bg-gradient-to-br from-indigo-400 to-purple-500 flex items-center justify-center text-white text-xs font-bold shrink-0">
                            {user.name.split(" ").map(n => n[0]).join("").slice(0, 2)}
                          </div>
                          <div>
                            <p className="text-sm font-semibold text-slate-800 dark:text-slate-100">{user.name}</p>
                            <p className="text-xs text-slate-400">{user.email}</p>
                          </div>
                        </div>
                      </td>
                      <td className="p-4 hidden md:table-cell">
                        <Badge variant={user.level === "Avanzado" ? "danger" : user.level === "Intermedio" ? "warning" : "success"} className="text-[10px]">
                          {user.level}
                        </Badge>
                      </td>
                      <td className="p-4 hidden lg:table-cell">
                        <span className="text-sm font-semibold text-slate-700 dark:text-slate-300">{user.sessions}</span>
                      </td>
                      <td className="p-4">
                        <Badge variant={user.status === "Activo" ? "success" : "default"} className="text-[10px]">
                          {user.status}
                        </Badge>
                      </td>
                      <td className="p-4">
                        <div className="flex items-center justify-end gap-1">
                          <button className="p-1.5 text-indigo-400 hover:bg-indigo-50 dark:hover:bg-indigo-950/30 rounded-lg transition-colors">
                            <Edit2 size={14} />
                          </button>
                          <button className="p-1.5 text-red-400 hover:bg-red-50 dark:hover:bg-red-950/30 rounded-lg transition-colors">
                            <Trash2 size={14} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Pagination */}
            <div className="flex items-center justify-between px-4 py-3 border-t border-slate-100 dark:border-slate-700">
              <p className="text-xs text-slate-400">Mostrando {filteredUsers.length} de 12,847 usuarios</p>
              <div className="flex gap-1">
                {[1, 2, 3, "...", 100].map((p, i) => (
                  <button key={i} className={`w-7 h-7 rounded-lg text-xs font-medium transition-all ${
                    p === 1 ? "bg-indigo-600 text-white" : "text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700"
                  }`}>{p}</button>
                ))}
              </div>
            </div>
          </Card>
        </motion.div>
      )}

      {/* EXERCISES */}
      {activeTab === "exercises" && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-4">
          <div className="flex gap-2">
            <div className="relative flex-1">
              <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                placeholder="Buscar ejercicios..."
                value={search}
                onChange={e => setSearch(e.target.value)}
                className="w-full pl-9 pr-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800/50 text-slate-800 dark:text-slate-100 placeholder:text-slate-400 text-sm focus:outline-none focus:border-indigo-500"
              />
            </div>
            <button className="flex items-center gap-1.5 px-4 py-2.5 bg-indigo-600 text-white rounded-xl text-sm font-bold hover:bg-indigo-700 transition-colors shrink-0">
              <Plus size={16} /> Añadir
            </button>
          </div>

          <Card>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="border-b border-slate-100 dark:border-slate-700">
                  <tr className="text-xs text-slate-400 dark:text-slate-500 uppercase">
                    <th className="text-left p-4 font-semibold">Ejercicio</th>
                    <th className="text-left p-4 font-semibold hidden sm:table-cell">Grupo</th>
                    <th className="text-left p-4 font-semibold hidden md:table-cell">Nivel</th>
                    <th className="text-left p-4 font-semibold hidden lg:table-cell">Usos</th>
                    <th className="text-left p-4 font-semibold">Estado</th>
                    <th className="text-right p-4 font-semibold">Acciones</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-50 dark:divide-slate-700/50">
                  {filteredExercises.map((ex) => (
                    <tr key={ex.id} className="hover:bg-slate-50 dark:hover:bg-slate-700/30 transition-colors">
                      <td className="p-4">
                        <div>
                          <p className="text-sm font-semibold text-slate-800 dark:text-slate-100">{ex.name}</p>
                          <p className="text-xs text-slate-400 hidden sm:block">{ex.equipment}</p>
                        </div>
                      </td>
                      <td className="p-4 hidden sm:table-cell">
                        <span className="text-sm text-slate-600 dark:text-slate-400">{ex.muscle}</span>
                      </td>
                      <td className="p-4 hidden md:table-cell">
                        <Badge variant={ex.level === "Avanzado" ? "danger" : ex.level === "Intermedio" ? "warning" : "success"} className="text-[10px]">
                          {ex.level}
                        </Badge>
                      </td>
                      <td className="p-4 hidden lg:table-cell">
                        <span className="text-sm font-semibold text-slate-700 dark:text-slate-300">{ex.uses.toLocaleString()}</span>
                      </td>
                      <td className="p-4">
                        <Badge variant={ex.status === "Publicado" ? "success" : "default"} className="text-[10px]">
                          {ex.status}
                        </Badge>
                      </td>
                      <td className="p-4">
                        <div className="flex items-center justify-end gap-1">
                          <button className="p-1.5 text-indigo-400 hover:bg-indigo-50 dark:hover:bg-indigo-950/30 rounded-lg transition-colors">
                            <Edit2 size={14} />
                          </button>
                          <button className="p-1.5 text-red-400 hover:bg-red-50 dark:hover:bg-red-950/30 rounded-lg transition-colors">
                            <Trash2 size={14} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>
        </motion.div>
      )}
    </div>
  );
};
