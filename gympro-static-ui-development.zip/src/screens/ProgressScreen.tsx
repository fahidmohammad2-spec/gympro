import React, { useState } from "react";
import { motion } from "framer-motion";
import { TrendingUp, TrendingDown, Camera, Plus, Scale, Activity } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/Card";
import { Badge } from "@/components/ui/Badge";
import {
  XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, AreaChart, Area, BarChart, Bar
} from "recharts";

const weightData = [
  { date: "Nov 15", weight: 81 },
  { date: "Nov 22", weight: 80.5 },
  { date: "Nov 29", weight: 80 },
  { date: "Dic 6", weight: 79.5 },
  { date: "Dic 13", weight: 79 },
  { date: "Dic 20", weight: 79 },
  { date: "Dic 27", weight: 78.5 },
  { date: "Ene 3", weight: 78 },
  { date: "Ene 10", weight: 78 },
  { date: "Ene 15", weight: 78 },
];

const strengthData = [
  { date: "Nov", bench: 75, squat: 90, deadlift: 110 },
  { date: "Dic", bench: 80, squat: 95, deadlift: 115 },
  { date: "Ene", bench: 90, squat: 100, deadlift: 120 },
];

const bodyMeasurements = [
  { label: "Pecho", before: 98, current: 100, unit: "cm" },
  { label: "Cintura", before: 84, current: 82, unit: "cm" },
  { label: "Cadera", before: 96, current: 95, unit: "cm" },
  { label: "Muslo", before: 58, current: 60, unit: "cm" },
  { label: "Brazo", before: 35, current: 37, unit: "cm" },
  { label: "% Grasa", before: 18, current: 16.5, unit: "%" },
];

const bodyHistory = [
  { date: "15 Nov 2024", weight: 81, fat: 18, muscle: 63 },
  { date: "15 Dic 2024", weight: 79.5, fat: 17.2, muscle: 63.8 },
  { date: "15 Ene 2025", weight: 78, fat: 16.5, muscle: 64.5 },
];

const photoPlaceholders = [
  { date: "Nov 2024", label: "Inicio", side: "Frente" },
  { date: "Nov 2024", label: "Inicio", side: "Perfil" },
  { date: "Nov 2024", label: "Inicio", side: "Espalda" },
  { date: "Dic 2024", label: "Mes 1", side: "Frente" },
  { date: "Dic 2024", label: "Mes 1", side: "Perfil" },
  { date: "Dic 2024", label: "Mes 1", side: "Espalda" },
  { date: "Ene 2025", label: "Mes 2", side: "Frente" },
  { date: "Ene 2025", label: "Mes 2", side: "Perfil" },
];

const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-3 shadow-lg text-xs">
        <p className="font-bold text-slate-700 dark:text-slate-200 mb-1">{label}</p>
        {payload.map((p: any) => (
          <p key={p.name} style={{ color: p.color }}>{p.name}: <strong>{p.value}</strong></p>
        ))}
      </div>
    );
  }
  return null;
};

export const ProgressScreen: React.FC = () => {
  const [activeTab, setActiveTab] = useState<"body" | "strength" | "photos">("body");

  return (
    <div className="space-y-5">
      {/* Summary cards */}
      <div className="grid grid-cols-3 gap-3">
        {[
          { icon: "⚖️", label: "Peso perdido", value: "−3 kg", sub: "en 2 meses", color: "text-emerald-500", bg: "bg-emerald-50 dark:bg-emerald-950/30" },
          { icon: "💪", label: "Músculo ganado", value: "+1.5 kg", sub: "masa magra", color: "text-blue-500", bg: "bg-blue-50 dark:bg-blue-950/30" },
          { icon: "🔥", label: "Grasa perdida", value: "−1.5%", sub: "porcentaje", color: "text-orange-500", bg: "bg-orange-50 dark:bg-orange-950/30" },
        ].map((s) => (
          <Card key={s.label}>
            <CardContent className="p-3 text-center">
              <span className="text-2xl">{s.icon}</span>
              <p className={`font-black text-lg mt-1 ${s.color}`}>{s.value}</p>
              <p className="text-xs font-semibold text-slate-700 dark:text-slate-300">{s.label}</p>
              <p className="text-[10px] text-slate-400">{s.sub}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Tabs */}
      <div className="flex gap-2 bg-slate-100 dark:bg-slate-800 p-1 rounded-xl">
        {[
          { id: "body", label: "Cuerpo" },
          { id: "strength", label: "Fuerza" },
          { id: "photos", label: "Fotos" },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as typeof activeTab)}
            className={`flex-1 py-2 text-sm font-semibold rounded-lg transition-all duration-200 ${
              activeTab === tab.id
                ? "bg-white dark:bg-slate-700 text-indigo-600 dark:text-indigo-400 shadow-sm"
                : "text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-300"
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Body tab */}
      {activeTab === "body" && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-5">
          {/* Weight chart */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  <Scale size={18} className="text-indigo-500" />
                  Evolución del peso
                </CardTitle>
                <Badge variant="success" className="flex items-center gap-1">
                  <TrendingDown size={12} /> −3 kg
                </Badge>
              </div>
            </CardHeader>
            <CardContent>
              <div className="h-48">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={weightData}>
                    <defs>
                      <linearGradient id="weightGrad" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#6366f1" stopOpacity={0.2} />
                        <stop offset="95%" stopColor="#6366f1" stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                    <XAxis dataKey="date" tick={{ fontSize: 10, fill: "#94a3b8" }} tickLine={false} />
                    <YAxis domain={[76, 82]} tick={{ fontSize: 10, fill: "#94a3b8" }} tickLine={false} axisLine={false} unit=" kg" />
                    <Tooltip content={<CustomTooltip />} />
                    <Area
                      type="monotone"
                      dataKey="weight"
                      name="Peso"
                      stroke="#6366f1"
                      strokeWidth={2.5}
                      fill="url(#weightGrad)"
                      dot={{ fill: "#6366f1", strokeWidth: 2, r: 3 }}
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>

          {/* Body measurements */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  <Activity size={18} className="text-purple-500" />
                  Medidas corporales
                </CardTitle>
                <button className="flex items-center gap-1 text-xs text-indigo-500 hover:text-indigo-600 font-medium">
                  <Plus size={12} /> Registrar
                </button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {bodyMeasurements.map((m) => {
                  const change = m.current - m.before;
                  const positive = m.label === "Cintura" || m.label === "% Grasa" ? change < 0 : change > 0;
                  return (
                    <div key={m.label} className="flex items-center gap-3">
                      <span className="text-xs font-medium text-slate-600 dark:text-slate-400 w-16 shrink-0">{m.label}</span>
                      <div className="flex-1 h-2 bg-slate-100 dark:bg-slate-700 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-gradient-to-r from-indigo-500 to-purple-500 rounded-full"
                          style={{ width: `${(m.current / (m.label === "% Grasa" ? 30 : 110)) * 100}%` }}
                        />
                      </div>
                      <span className="text-sm font-bold text-slate-800 dark:text-slate-100 w-16 text-right shrink-0">
                        {m.current}{m.unit}
                      </span>
                      <span className={`text-xs font-semibold w-10 text-right shrink-0 flex items-center gap-0.5 ${positive ? "text-emerald-500" : "text-red-500"}`}>
                        {positive ? <TrendingUp size={11} /> : <TrendingDown size={11} />}
                        {Math.abs(change).toFixed(1)}
                      </span>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>

          {/* History table */}
          <Card>
            <CardHeader>
              <CardTitle>Historial de registros</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="text-xs text-slate-400 dark:text-slate-500 uppercase border-b border-slate-100 dark:border-slate-700">
                      <th className="text-left pb-2 font-semibold">Fecha</th>
                      <th className="text-right pb-2 font-semibold">Peso</th>
                      <th className="text-right pb-2 font-semibold">% Grasa</th>
                      <th className="text-right pb-2 font-semibold">Músculo</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-50 dark:divide-slate-700/50">
                    {bodyHistory.map((row) => (
                      <tr key={row.date} className="hover:bg-slate-50 dark:hover:bg-slate-700/30 transition-colors">
                        <td className="py-2.5 text-slate-600 dark:text-slate-400">{row.date}</td>
                        <td className="py-2.5 text-right font-semibold text-slate-800 dark:text-slate-100">{row.weight} kg</td>
                        <td className="py-2.5 text-right font-semibold text-orange-500">{row.fat}%</td>
                        <td className="py-2.5 text-right font-semibold text-blue-500">{row.muscle} kg</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Log form */}
              <div className="mt-4 p-4 bg-slate-50 dark:bg-slate-700/50 rounded-xl space-y-3">
                <p className="text-sm font-bold text-slate-700 dark:text-slate-300">Nuevo registro</p>
                <div className="grid grid-cols-2 gap-3">
                  {[
                    { label: "Peso (kg)", default: "78" },
                    { label: "% Grasa", default: "16.5" },
                    { label: "Cintura (cm)", default: "82" },
                    { label: "Cadera (cm)", default: "95" },
                  ].map(f => (
                    <div key={f.label}>
                      <label className="text-xs text-slate-500 dark:text-slate-400 mb-1 block">{f.label}</label>
                      <input
                        type="number"
                        defaultValue={f.default}
                        className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-600 bg-white dark:bg-slate-700 text-slate-800 dark:text-slate-100 text-sm focus:outline-none focus:border-indigo-500"
                      />
                    </div>
                  ))}
                </div>
                <button className="w-full py-2.5 bg-indigo-600 text-white font-semibold rounded-xl hover:bg-indigo-700 transition-colors text-sm flex items-center justify-center gap-2">
                  <Plus size={15} />
                  Guardar registro
                </button>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      )}

      {/* Strength tab */}
      {activeTab === "strength" && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-5">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp size={18} className="text-indigo-500" />
                Progresión de fuerza (1RM estimado)
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-52">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={strengthData} barGap={4}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                    <XAxis dataKey="date" tick={{ fontSize: 11, fill: "#94a3b8" }} tickLine={false} />
                    <YAxis tick={{ fontSize: 11, fill: "#94a3b8" }} tickLine={false} axisLine={false} unit=" kg" />
                    <Tooltip content={<CustomTooltip />} />
                    <Bar dataKey="bench" name="Press Banca" fill="#6366f1" radius={[4, 4, 0, 0]} />
                    <Bar dataKey="squat" name="Sentadilla" fill="#8b5cf6" radius={[4, 4, 0, 0]} />
                    <Bar dataKey="deadlift" name="Peso Muerto" fill="#ec4899" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
              <div className="flex justify-center gap-4 mt-2 text-xs">
                {[
                  { color: "bg-indigo-500", label: "Press Banca" },
                  { color: "bg-purple-500", label: "Sentadilla" },
                  { color: "bg-pink-500", label: "Peso Muerto" },
                ].map(l => (
                  <div key={l.label} className="flex items-center gap-1.5">
                    <div className={`w-3 h-3 rounded ${l.color}`} />
                    <span className="text-slate-500 dark:text-slate-400">{l.label}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* PRs */}
          <Card>
            <CardHeader>
              <CardTitle>🏆 Récords Personales (1RM)</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {[
                  { name: "Press de Banca", pr: 100, date: "10 Ene", trend: "+5kg" },
                  { name: "Sentadilla", pr: 120, date: "8 Ene", trend: "+10kg" },
                  { name: "Peso Muerto", pr: 140, date: "5 Ene", trend: "+10kg" },
                  { name: "Press Militar", pr: 70, date: "12 Ene", trend: "+5kg" },
                  { name: "Dominadas", pr: 25, date: "14 Ene", trend: "+5kg extra" },
                ].map((pr) => (
                  <div key={pr.name} className="flex items-center gap-3 p-3 bg-slate-50 dark:bg-slate-700/50 rounded-xl">
                    <div className="w-8 h-8 rounded-full bg-amber-100 dark:bg-amber-900/40 flex items-center justify-center">
                      <span className="text-sm">🏆</span>
                    </div>
                    <div className="flex-1">
                      <p className="text-sm font-semibold text-slate-800 dark:text-slate-100">{pr.name}</p>
                      <p className="text-xs text-slate-400">{pr.date}</p>
                    </div>
                    <div className="text-right">
                      <p className="font-black text-slate-800 dark:text-slate-100">{pr.pr} kg</p>
                      <Badge variant="success" className="text-[10px]">{pr.trend}</Badge>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </motion.div>
      )}

      {/* Photos tab */}
      {activeTab === "photos" && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-5">
          {/* Before / After comparison */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Camera size={18} className="text-purple-500" />
                Comparación Antes / Después
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="relative h-52 rounded-xl overflow-hidden flex">
                {/* Before side */}
                <div className="flex-1 bg-gradient-to-br from-slate-200 to-slate-300 dark:from-slate-700 dark:to-slate-800 flex flex-col items-center justify-center gap-2">
                  <div className="w-16 h-16 rounded-full bg-slate-300 dark:bg-slate-600 flex items-center justify-center">
                    <span className="text-2xl">👤</span>
                  </div>
                  <p className="text-xs font-semibold text-slate-600 dark:text-slate-400">Nov 2024</p>
                  <Badge variant="default">Antes · 81 kg</Badge>
                </div>
                {/* Divider */}
                <div className="w-0.5 bg-white dark:bg-slate-900 z-10 relative">
                  <div className="absolute top-1/2 -translate-y-1/2 left-1/2 -translate-x-1/2 w-8 h-8 rounded-full bg-white dark:bg-slate-800 border-2 border-slate-200 dark:border-slate-700 flex items-center justify-center shadow-md">
                    <span className="text-xs font-bold text-slate-500">↔</span>
                  </div>
                </div>
                {/* After side */}
                <div className="flex-1 bg-gradient-to-br from-indigo-100 to-purple-100 dark:from-indigo-950/40 dark:to-purple-950/40 flex flex-col items-center justify-center gap-2">
                  <div className="w-16 h-16 rounded-full bg-indigo-200 dark:bg-indigo-900/60 flex items-center justify-center">
                    <span className="text-2xl">💪</span>
                  </div>
                  <p className="text-xs font-semibold text-indigo-600 dark:text-indigo-400">Ene 2025</p>
                  <Badge variant="info">Después · 78 kg</Badge>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Photo gallery */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-bold text-slate-800 dark:text-slate-100">Galería de progreso</h3>
              <button className="flex items-center gap-1.5 px-3 py-1.5 bg-indigo-600 text-white rounded-xl text-xs font-bold hover:bg-indigo-700 transition-colors">
                <Camera size={13} /> Añadir foto
              </button>
            </div>
            <div className="grid grid-cols-3 gap-2">
              {photoPlaceholders.map((photo, i) => (
                <div
                  key={i}
                  className="aspect-square rounded-xl bg-gradient-to-br from-slate-100 to-slate-200 dark:from-slate-700 dark:to-slate-800 flex flex-col items-center justify-center gap-1 border border-slate-200 dark:border-slate-700 hover:border-indigo-300 dark:hover:border-indigo-700 transition-all cursor-pointer group"
                >
                  <span className="text-2xl group-hover:scale-110 transition-transform">📷</span>
                  <p className="text-[10px] font-semibold text-slate-500 dark:text-slate-400">{photo.label}</p>
                  <p className="text-[9px] text-slate-400">{photo.side}</p>
                  <p className="text-[9px] text-slate-300 dark:text-slate-600">{photo.date}</p>
                </div>
              ))}
              {/* Add photo button */}
              <div className="aspect-square rounded-xl border-2 border-dashed border-slate-200 dark:border-slate-700 flex flex-col items-center justify-center gap-1 hover:border-indigo-300 dark:hover:border-indigo-700 transition-all cursor-pointer">
                <Plus size={20} className="text-slate-300 dark:text-slate-600" />
                <p className="text-[10px] text-slate-400">Añadir</p>
              </div>
            </div>
          </div>
        </motion.div>
      )}
    </div>
  );
};
