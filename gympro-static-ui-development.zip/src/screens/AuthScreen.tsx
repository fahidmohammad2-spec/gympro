import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Mail, Lock, User, Phone, Eye, EyeOff, Dumbbell,
  ArrowRight, Calendar, ChevronDown, Target, Zap
} from "lucide-react";


interface AuthScreenProps {
  onNavigate: (page: string) => void;
}

const objectives = [
  { id: "fat_loss", label: "Perder grasa", icon: "🔥" },
  { id: "muscle", label: "Ganar músculo", icon: "💪" },
  { id: "strength", label: "Mejorar fuerza", icon: "⚡" },
  { id: "endurance", label: "Resistencia", icon: "🏃" },
  { id: "health", label: "Salud general", icon: "❤️" },
];

export const AuthScreen: React.FC<AuthScreenProps> = ({ onNavigate }) => {
  const [tab, setTab] = useState<"login" | "register">("login");
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [selectedObjectives, setSelectedObjectives] = useState<string[]>(["muscle"]);

  const toggleObjective = (id: string) => {
    setSelectedObjectives(prev =>
      prev.includes(id) ? prev.filter(o => o !== id) : [...prev, id]
    );
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-900 flex items-center justify-center p-4">
      {/* Background decoration */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-indigo-600/10 rounded-full blur-3xl" />
        <div className="absolute bottom-0 left-0 w-[400px] h-[400px] bg-purple-600/10 rounded-full blur-3xl" />
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="relative w-full max-w-md"
      >
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-br from-indigo-500 to-purple-600 mb-4 shadow-xl shadow-indigo-500/30">
            <Dumbbell size={28} className="text-white" />
          </div>
          <h1 className="text-3xl font-black text-white">
            Gym<span className="text-indigo-400">Pro</span>
          </h1>
          <p className="text-slate-400 text-sm mt-1">Tu compañero de entrenamiento definitivo</p>
        </div>

        {/* Card */}
        <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl overflow-hidden shadow-2xl">
          {/* Tabs */}
          <div className="flex border-b border-white/10">
            {[
              { id: "login", label: "Iniciar Sesión" },
              { id: "register", label: "Registrarse" },
            ].map((t) => (
              <button
                key={t.id}
                onClick={() => setTab(t.id as "login" | "register")}
                className={`flex-1 py-4 text-sm font-semibold transition-all duration-200 ${
                  tab === t.id
                    ? "text-white border-b-2 border-indigo-500 bg-indigo-600/10"
                    : "text-slate-400 hover:text-slate-200"
                }`}
              >
                {t.label}
              </button>
            ))}
          </div>

          <div className="p-6">
            <AnimatePresence mode="wait">
              {tab === "login" ? (
                <motion.div
                  key="login"
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 20 }}
                  className="space-y-4"
                >
                  {/* Social buttons */}
                  <div className="grid grid-cols-2 gap-3">
                    <button className="flex items-center justify-center gap-2 py-2.5 px-4 bg-white/10 hover:bg-white/15 border border-white/10 rounded-xl text-white text-sm font-medium transition-all">
                      <svg className="w-4 h-4" viewBox="0 0 24 24">
                        <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                        <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                        <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
                        <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
                      </svg>
                      Google
                    </button>
                    <button className="flex items-center justify-center gap-2 py-2.5 px-4 bg-white/10 hover:bg-white/15 border border-white/10 rounded-xl text-white text-sm font-medium transition-all">
                      <svg className="w-4 h-4 text-white fill-current" viewBox="0 0 24 24">
                        <path d="M12.017 0C5.396 0 .029 5.367.029 11.987c0 5.079 3.158 9.417 7.618 11.162-.105-.949-.2-2.405.042-3.441.218-.937 1.407-5.965 1.407-5.965s-.359-.719-.359-1.782c0-1.668.967-2.914 2.171-2.914 1.023 0 1.518.769 1.518 1.69 0 1.029-.655 2.568-.994 3.995-.283 1.194.599 2.169 1.777 2.169 2.133 0 3.772-2.249 3.772-5.495 0-2.873-2.064-4.882-5.012-4.882-3.414 0-5.418 2.561-5.418 5.207 0 1.031.397 2.138.893 2.738a.36.36 0 0 1 .083.345l-.333 1.36c-.053.22-.174.267-.402.161-1.499-.698-2.436-2.889-2.436-4.649 0-3.785 2.75-7.262 7.929-7.262 4.163 0 7.398 2.967 7.398 6.931 0 4.136-2.607 7.464-6.227 7.464-1.216 0-2.359-.632-2.75-1.378l-.748 2.853c-.271 1.043-1.002 2.35-1.492 3.146C9.57 23.812 10.763 24 12.017 24c6.624 0 11.99-5.367 11.99-11.987C24.007 5.367 18.641.001 12.017.001z"/>
                      </svg>
                      Apple
                    </button>
                  </div>

                  <div className="flex items-center gap-3">
                    <div className="flex-1 h-px bg-white/10" />
                    <span className="text-xs text-slate-500">o con email</span>
                    <div className="flex-1 h-px bg-white/10" />
                  </div>

                  {/* Login form */}
                  <div className="space-y-3">
                    <div className="relative">
                      <Mail size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 z-10" />
                      <input
                        type="email"
                        placeholder="correo@ejemplo.com"
                        defaultValue="carlos@example.com"
                        className="w-full pl-10 pr-4 py-3 bg-white/10 border border-white/10 rounded-xl text-white placeholder:text-slate-500 text-sm focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500/30 transition-all"
                      />
                    </div>
                    <div className="relative">
                      <Lock size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 z-10" />
                      <input
                        type={showPassword ? "text" : "password"}
                        placeholder="Tu contraseña"
                        defaultValue="••••••••"
                        className="w-full pl-10 pr-10 py-3 bg-white/10 border border-white/10 rounded-xl text-white placeholder:text-slate-500 text-sm focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500/30 transition-all"
                      />
                      <button
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white transition-colors"
                      >
                        {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                      </button>
                    </div>
                  </div>

                  <div className="text-right">
                    <button className="text-xs text-indigo-400 hover:text-indigo-300 transition-colors">
                      ¿Olvidaste tu contraseña?
                    </button>
                  </div>

                  <button
                    onClick={() => onNavigate("dashboard")}
                    className="w-full py-3 bg-gradient-to-r from-indigo-500 to-purple-600 text-white font-bold rounded-xl hover:shadow-lg hover:shadow-indigo-500/30 transition-all duration-200 flex items-center justify-center gap-2 btn-press"
                  >
                    Iniciar Sesión
                    <ArrowRight size={16} />
                  </button>

                  <p className="text-center text-xs text-slate-500">
                    ¿No tienes cuenta?{" "}
                    <button onClick={() => setTab("register")} className="text-indigo-400 hover:text-indigo-300 font-medium">
                      Regístrate gratis
                    </button>
                  </p>
                </motion.div>
              ) : (
                <motion.div
                  key="register"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className="space-y-4 max-h-[65vh] overflow-y-auto no-scrollbar"
                >
                  {/* Name row */}
                  <div className="grid grid-cols-2 gap-3">
                    <div className="relative">
                      <User size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 z-10" />
                      <input placeholder="Nombre" defaultValue="Carlos"
                        className="w-full pl-9 pr-3 py-2.5 bg-white/10 border border-white/10 rounded-xl text-white placeholder:text-slate-500 text-sm focus:outline-none focus:border-indigo-500 transition-all" />
                    </div>
                    <div className="relative">
                      <User size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 z-10" />
                      <input placeholder="Apellidos" defaultValue="Andrés García"
                        className="w-full pl-9 pr-3 py-2.5 bg-white/10 border border-white/10 rounded-xl text-white placeholder:text-slate-500 text-sm focus:outline-none focus:border-indigo-500 transition-all" />
                    </div>
                  </div>

                  <div className="relative">
                    <Mail size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 z-10" />
                    <input type="email" placeholder="Correo electrónico"
                      className="w-full pl-9 pr-3 py-2.5 bg-white/10 border border-white/10 rounded-xl text-white placeholder:text-slate-500 text-sm focus:outline-none focus:border-indigo-500 transition-all" />
                  </div>

                  <div className="relative">
                    <Phone size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 z-10" />
                    <input type="tel" placeholder="Teléfono"
                      className="w-full pl-9 pr-3 py-2.5 bg-white/10 border border-white/10 rounded-xl text-white placeholder:text-slate-500 text-sm focus:outline-none focus:border-indigo-500 transition-all" />
                  </div>

                  {/* Password */}
                  <div className="relative">
                    <Lock size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 z-10" />
                    <input type={showPassword ? "text" : "password"} placeholder="Contraseña (mín. 8 caracteres)"
                      className="w-full pl-9 pr-10 py-2.5 bg-white/10 border border-white/10 rounded-xl text-white placeholder:text-slate-500 text-sm focus:outline-none focus:border-indigo-500 transition-all" />
                    <button onClick={() => setShowPassword(!showPassword)} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400">
                      {showPassword ? <EyeOff size={14} /> : <Eye size={14} />}
                    </button>
                  </div>

                  <div className="relative">
                    <Lock size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 z-10" />
                    <input type={showConfirmPassword ? "text" : "password"} placeholder="Confirmar contraseña"
                      className="w-full pl-9 pr-10 py-2.5 bg-white/10 border border-white/10 rounded-xl text-white placeholder:text-slate-500 text-sm focus:outline-none focus:border-indigo-500 transition-all" />
                    <button onClick={() => setShowConfirmPassword(!showConfirmPassword)} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400">
                      {showConfirmPassword ? <EyeOff size={14} /> : <Eye size={14} />}
                    </button>
                  </div>

                  {/* Date of birth + Sex */}
                  <div className="grid grid-cols-2 gap-3">
                    <div className="relative">
                      <Calendar size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 z-10" />
                      <input type="date" defaultValue="1995-03-15"
                        className="w-full pl-9 pr-3 py-2.5 bg-white/10 border border-white/10 rounded-xl text-white text-sm focus:outline-none focus:border-indigo-500 transition-all [color-scheme:dark]" />
                    </div>
                    <div className="relative">
                      <ChevronDown size={14} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 z-10 pointer-events-none" />
                      <select className="w-full px-3 py-2.5 bg-white/10 border border-white/10 rounded-xl text-white text-sm focus:outline-none focus:border-indigo-500 appearance-none [color-scheme:dark]">
                        <option value="">Sexo</option>
                        <option value="m">Masculino</option>
                        <option value="f">Femenino</option>
                        <option value="o">Otro</option>
                      </select>
                    </div>
                  </div>

                  {/* Height + Weight */}
                  <div className="grid grid-cols-2 gap-3">
                    <div className="relative">
                      <input type="number" placeholder="Altura (cm)" defaultValue="178"
                        className="w-full px-3 py-2.5 bg-white/10 border border-white/10 rounded-xl text-white placeholder:text-slate-500 text-sm focus:outline-none focus:border-indigo-500 transition-all" />
                    </div>
                    <div className="relative">
                      <input type="number" placeholder="Peso (kg)" defaultValue="78"
                        className="w-full px-3 py-2.5 bg-white/10 border border-white/10 rounded-xl text-white placeholder:text-slate-500 text-sm focus:outline-none focus:border-indigo-500 transition-all" />
                    </div>
                  </div>

                  {/* Level */}
                  <div className="relative">
                    <ChevronDown size={14} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 z-10 pointer-events-none" />
                    <select className="w-full px-3 py-2.5 bg-white/10 border border-white/10 rounded-xl text-white text-sm focus:outline-none focus:border-indigo-500 appearance-none [color-scheme:dark]">
                      <option value="">Nivel de experiencia</option>
                      <option value="beginner">Principiante</option>
                      <option value="intermediate" selected>Intermedio</option>
                      <option value="advanced">Avanzado</option>
                    </select>
                  </div>

                  {/* Objectives */}
                  <div>
                    <p className="text-xs text-slate-400 mb-2 flex items-center gap-1">
                      <Target size={12} />
                      Objetivos (selecciona los que apliquen)
                    </p>
                    <div className="flex flex-wrap gap-2">
                      {objectives.map((obj) => (
                        <button
                          key={obj.id}
                          onClick={() => toggleObjective(obj.id)}
                          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium border transition-all duration-200 ${
                            selectedObjectives.includes(obj.id)
                              ? "bg-indigo-600 border-indigo-500 text-white"
                              : "border-white/10 text-slate-400 hover:border-indigo-500/50"
                          }`}
                        >
                          {obj.icon} {obj.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Terms */}
                  <label className="flex items-start gap-2 cursor-pointer">
                    <input type="checkbox" defaultChecked className="mt-0.5 w-4 h-4 rounded border-slate-600 accent-indigo-500" />
                    <span className="text-xs text-slate-400">
                      Acepto los{" "}
                      <span className="text-indigo-400 hover:text-indigo-300 cursor-pointer">Términos de Servicio</span>
                      {" "}y la{" "}
                      <span className="text-indigo-400 hover:text-indigo-300 cursor-pointer">Política de Privacidad</span>
                    </span>
                  </label>

                  <button
                    onClick={() => onNavigate("onboarding")}
                    className="w-full py-3 bg-gradient-to-r from-indigo-500 to-purple-600 text-white font-bold rounded-xl hover:shadow-lg hover:shadow-indigo-500/30 transition-all duration-200 flex items-center justify-center gap-2 btn-press"
                  >
                    <Zap size={16} />
                    Crear cuenta gratis
                  </button>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>

        <p className="text-center text-xs text-slate-600 mt-6">
          🔒 Tus datos están seguros y encriptados
        </p>
      </motion.div>
    </div>
  );
};
