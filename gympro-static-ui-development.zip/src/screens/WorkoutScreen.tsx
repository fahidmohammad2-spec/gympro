import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Play, Pause, Square, ChevronDown, ChevronUp,
  Timer, CheckCircle, Circle, Plus, Minus,
  Flame, Award, RotateCcw
} from "lucide-react";
import { Card, CardContent } from "@/components/ui/Card";
import { Badge } from "@/components/ui/Badge";
import { cn } from "@/utils/cn";

const workoutExercises = [
  {
    id: 1, name: "Sentadilla con Barra", emoji: "🦵", muscle: "Cuádriceps",
    sets: [
      { weight: 80, reps: 10, rpe: 7, rir: 3, done: true },
      { weight: 85, reps: 8, rpe: 8, rir: 2, done: true },
      { weight: 85, reps: 8, rpe: 8, rir: 2, done: false },
      { weight: 90, reps: 6, rpe: 9, rir: 1, done: false },
    ]
  },
  {
    id: 2, name: "Prensa de Pierna", emoji: "🏋️", muscle: "Cuádriceps/Glúteos",
    sets: [
      { weight: 120, reps: 12, rpe: 7, rir: 3, done: false },
      { weight: 130, reps: 10, rpe: 8, rir: 2, done: false },
      { weight: 130, reps: 10, rpe: 8, rir: 2, done: false },
    ]
  },
  {
    id: 3, name: "Extensiones de Cuádriceps", emoji: "⚡", muscle: "Cuádriceps",
    sets: [
      { weight: 40, reps: 15, rpe: 7, rir: 3, done: false },
      { weight: 40, reps: 15, rpe: 7, rir: 3, done: false },
      { weight: 45, reps: 12, rpe: 8, rir: 2, done: false },
    ]
  },
  {
    id: 4, name: "Hip Thrust", emoji: "🍑", muscle: "Glúteos/Femorales",
    sets: [
      { weight: 100, reps: 10, rpe: 8, rir: 2, done: false },
      { weight: 100, reps: 10, rpe: 8, rir: 2, done: false },
      { weight: 105, reps: 8, rpe: 9, rir: 1, done: false },
    ]
  },
];

export const WorkoutScreen: React.FC = () => {
  const [timerRunning, setTimerRunning] = useState(true);
  const [restTimerActive, setRestTimerActive] = useState(false);
  const [completedSets, setCompletedSets] = useState<Set<string>>(new Set(["1-0", "1-1"]));
  const [expandedExercise, setExpandedExercise] = useState<number | null>(1);
  const [showSummary, setShowSummary] = useState(false);

  const toggleSet = (key: string) => {
    setCompletedSets(prev => {
      const next = new Set(prev);
      if (next.has(key)) next.delete(key);
      else { next.add(key); setRestTimerActive(true); setTimeout(() => setRestTimerActive(false), 3000); }
      return next;
    });
  };

  const totalSets = workoutExercises.reduce((acc, e) => acc + e.sets.length, 0);
  const doneSets = completedSets.size;
  const progress = Math.round((doneSets / totalSets) * 100);

  if (showSummary) {
    return (
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="space-y-6"
      >
        {/* Summary card */}
        <div className="bg-gradient-to-br from-indigo-600 to-purple-700 rounded-3xl p-6 text-white text-center relative overflow-hidden">
          <div className="absolute top-0 right-0 w-40 h-40 bg-white/10 rounded-full -translate-y-1/2 translate-x-1/4" />
          <div className="relative">
            <div className="w-20 h-20 rounded-2xl bg-white/20 flex items-center justify-center mx-auto mb-4 backdrop-blur-sm">
              <Award size={36} className="text-white" />
            </div>
            <h2 className="text-2xl font-black mb-1">¡Entrenamiento completado!</h2>
            <p className="text-indigo-200 text-sm">Rutina de Pierna · Hoy</p>

            <div className="grid grid-cols-3 gap-4 mt-6">
              {[
                { icon: "⏱️", label: "Duración", value: "47:22" },
                { icon: "🔥", label: "Series", value: `${doneSets}/${totalSets}` },
                { icon: "💪", label: "Volumen", value: "3,240 kg" },
              ].map(s => (
                <div key={s.label} className="bg-white/10 rounded-2xl p-3 backdrop-blur-sm">
                  <p className="text-xl mb-1">{s.icon}</p>
                  <p className="font-black text-lg">{s.value}</p>
                  <p className="text-indigo-200 text-xs">{s.label}</p>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Exercise breakdown */}
        <Card>
          <CardContent className="p-4 space-y-3">
            <h3 className="font-bold text-slate-800 dark:text-slate-100">Resumen de ejercicios</h3>
            {workoutExercises.map((ex) => (
              <div key={ex.id} className="flex items-center gap-3 p-3 bg-slate-50 dark:bg-slate-700/50 rounded-xl">
                <span className="text-2xl">{ex.emoji}</span>
                <div className="flex-1">
                  <p className="text-sm font-semibold text-slate-800 dark:text-slate-100">{ex.name}</p>
                  <p className="text-xs text-slate-500 dark:text-slate-400">{ex.sets.length} series</p>
                </div>
                <div className="text-right">
                  <p className="text-sm font-bold text-indigo-600">{ex.sets[0].weight * ex.sets.length * ex.sets[0].reps} kg</p>
                  <p className="text-xs text-slate-400">volumen</p>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        {/* PRs */}
        <div className="bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800/40 rounded-2xl p-4">
          <p className="text-sm font-bold text-amber-700 dark:text-amber-400 mb-2">🏆 Récords personales</p>
          <div className="space-y-2">
            <div className="flex items-center justify-between text-sm">
              <span className="text-slate-700 dark:text-slate-300">Sentadilla con Barra</span>
              <Badge variant="warning">Nuevo RP: 90kg × 6</Badge>
            </div>
          </div>
        </div>

        {/* XP gained */}
        <Card className="bg-gradient-to-r from-indigo-50 to-purple-50 dark:from-indigo-950/30 dark:to-purple-950/30 border-indigo-200 dark:border-indigo-800/50">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-bold text-slate-700 dark:text-slate-300">XP ganado</p>
                <p className="text-3xl font-black text-indigo-600">+120 XP</p>
              </div>
              <div className="text-right">
                <p className="text-xs text-slate-500 dark:text-slate-400">Racha</p>
                <p className="text-2xl font-black text-orange-500">🔥 13</p>
              </div>
            </div>
            <div className="mt-3 h-2 bg-indigo-100 dark:bg-indigo-900/40 rounded-full overflow-hidden">
              <div className="h-full bg-indigo-600 rounded-full transition-all duration-1000" style={{ width: "72%" }} />
            </div>
            <p className="text-xs text-slate-400 mt-1.5">3,360 / 5,000 XP para Nivel 13</p>
          </CardContent>
        </Card>

        <button
          onClick={() => setShowSummary(false)}
          className="w-full py-4 bg-indigo-600 text-white font-black rounded-2xl hover:bg-indigo-700 transition-colors flex items-center justify-center gap-2 text-lg"
        >
          <RotateCcw size={20} />
          Volver al inicio
        </button>
      </motion.div>
    );
  }

  return (
    <div className="space-y-4 pb-6">
      {/* Timer header */}
      <div className="bg-gradient-to-r from-indigo-600 to-purple-700 rounded-2xl p-5 text-white">
        <div className="flex items-center justify-between mb-4">
          <div>
            <p className="text-indigo-200 text-sm">Entrenando ahora</p>
            <p className="font-bold text-lg">Rutina de Pierna 🦵</p>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setTimerRunning(!timerRunning)}
              className="w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center hover:bg-white/30 transition-colors"
            >
              {timerRunning ? <Pause size={18} /> : <Play size={18} />}
            </button>
            <button
              onClick={() => setShowSummary(true)}
              className="w-10 h-10 rounded-xl bg-red-500/80 flex items-center justify-center hover:bg-red-500 transition-colors"
            >
              <Square size={16} />
            </button>
          </div>
        </div>

        {/* Timer */}
        <div className="text-center mb-3">
          <p className={cn(
            "text-6xl font-black tracking-wider font-mono",
            timerRunning && "animate-timer-pulse"
          )}>
            00:12:34
          </p>
          <p className="text-indigo-200 text-sm mt-1">Tiempo de entrenamiento</p>
        </div>

        {/* Progress */}
        <div>
          <div className="flex justify-between text-sm mb-1">
            <span>{doneSets} series completadas</span>
            <span>{progress}%</span>
          </div>
          <div className="h-2 bg-white/20 rounded-full overflow-hidden">
            <div
              className="h-full bg-white rounded-full transition-all duration-500"
              style={{ width: `${progress}%` }}
            />
          </div>
        </div>
      </div>

      {/* Rest timer */}
      <AnimatePresence>
        {restTimerActive && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800/40 rounded-2xl p-4"
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-full bg-amber-100 dark:bg-amber-900/40 flex items-center justify-center">
                  <Timer size={20} className="text-amber-600" />
                </div>
                <div>
                  <p className="font-bold text-amber-700 dark:text-amber-400">Tiempo de descanso</p>
                  <p className="text-2xl font-black text-amber-700 dark:text-amber-400 font-mono animate-timer-pulse">1:30</p>
                </div>
              </div>
              <div className="flex gap-2">
                <button className="p-2 bg-amber-100 dark:bg-amber-900/40 rounded-xl text-amber-600 hover:bg-amber-200 dark:hover:bg-amber-900 transition-colors">
                  <Minus size={16} />
                </button>
                <button className="p-2 bg-amber-100 dark:bg-amber-900/40 rounded-xl text-amber-600 hover:bg-amber-200 dark:hover:bg-amber-900 transition-colors">
                  <Plus size={16} />
                </button>
                <button
                  onClick={() => setRestTimerActive(false)}
                  className="px-3 py-2 bg-amber-600 text-white rounded-xl text-xs font-bold hover:bg-amber-700 transition-colors"
                >
                  Saltar
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Exercises */}
      <div className="space-y-3">
        {workoutExercises.map((exercise) => (
          <Card key={exercise.id} className={cn(
            "overflow-hidden transition-all duration-200",
            expandedExercise === exercise.id && "ring-2 ring-indigo-500/30"
          )}>
            <button
              onClick={() => setExpandedExercise(expandedExercise === exercise.id ? null : exercise.id)}
              className="w-full p-4 flex items-center gap-3 text-left hover:bg-slate-50 dark:hover:bg-slate-700/30 transition-colors"
            >
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-indigo-100 to-purple-100 dark:from-indigo-900/40 dark:to-purple-900/40 flex items-center justify-center shrink-0">
                <span className="text-2xl">{exercise.emoji}</span>
              </div>
              <div className="flex-1">
                <p className="font-bold text-slate-800 dark:text-slate-100">{exercise.name}</p>
                <p className="text-xs text-slate-500 dark:text-slate-400">{exercise.muscle} · {exercise.sets.length} series</p>
              </div>
              <div className="flex items-center gap-2">
                <div className="flex gap-1">
                  {exercise.sets.map((_, si) => (
                    <div key={si} className={cn(
                      "w-2 h-2 rounded-full",
                      completedSets.has(`${exercise.id}-${si}`)
                        ? "bg-emerald-500"
                        : "bg-slate-200 dark:bg-slate-600"
                    )} />
                  ))}
                </div>
                {expandedExercise === exercise.id ? <ChevronUp size={16} className="text-slate-400" /> : <ChevronDown size={16} className="text-slate-400" />}
              </div>
            </button>

            {/* Sets */}
            <AnimatePresence>
              {expandedExercise === exercise.id && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: "auto", opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  className="overflow-hidden"
                >
                  <div className="px-4 pb-4 space-y-2">
                    {/* Header */}
                    <div className="grid grid-cols-7 gap-2 text-[10px] text-slate-400 dark:text-slate-500 font-semibold uppercase px-1">
                      <span>Serie</span>
                      <span className="col-span-2">Peso (kg)</span>
                      <span className="col-span-2">Reps</span>
                      <span>RPE</span>
                      <span>✓</span>
                    </div>

                    {exercise.sets.map((set, si) => {
                      const key = `${exercise.id}-${si}`;
                      const isDone = completedSets.has(key);
                      return (
                        <div
                          key={si}
                          className={cn(
                            "grid grid-cols-7 gap-2 items-center p-2.5 rounded-xl transition-all duration-200",
                            isDone
                              ? "bg-emerald-50 dark:bg-emerald-950/30"
                              : "bg-slate-50 dark:bg-slate-700/50"
                          )}
                        >
                          <span className={cn(
                            "text-sm font-bold text-center",
                            isDone ? "text-emerald-600" : "text-slate-400"
                          )}>
                            {si + 1}
                          </span>
                          <div className="col-span-2">
                            <input
                              type="number"
                              defaultValue={set.weight}
                              className="w-full text-center py-1.5 rounded-lg border border-slate-200 dark:border-slate-600 bg-white dark:bg-slate-700 text-slate-700 dark:text-slate-200 text-sm font-semibold focus:outline-none focus:border-indigo-500"
                            />
                          </div>
                          <div className="col-span-2">
                            <input
                              type="number"
                              defaultValue={set.reps}
                              className="w-full text-center py-1.5 rounded-lg border border-slate-200 dark:border-slate-600 bg-white dark:bg-slate-700 text-slate-700 dark:text-slate-200 text-sm font-semibold focus:outline-none focus:border-indigo-500"
                            />
                          </div>
                          <span className={cn(
                            "text-sm font-bold text-center",
                            isDone ? "text-emerald-600" : "text-slate-600 dark:text-slate-300"
                          )}>
                            {set.rpe}
                          </span>
                          <button
                            onClick={() => toggleSet(key)}
                            className="flex items-center justify-center"
                          >
                            {isDone ? (
                              <CheckCircle size={22} className="text-emerald-500" />
                            ) : (
                              <Circle size={22} className="text-slate-300 dark:text-slate-600 hover:text-indigo-400 transition-colors" />
                            )}
                          </button>
                        </div>
                      );
                    })}

                    {/* Add set */}
                    <button className="w-full py-2 flex items-center justify-center gap-2 text-indigo-500 hover:text-indigo-600 text-sm font-medium hover:bg-indigo-50 dark:hover:bg-indigo-950/20 rounded-xl transition-all">
                      <Plus size={15} />
                      Añadir serie
                    </button>

                    {/* Descanso button */}
                    <button
                      onClick={() => setRestTimerActive(true)}
                      className="w-full py-2.5 flex items-center justify-center gap-2 bg-amber-100 dark:bg-amber-950/30 text-amber-700 dark:text-amber-400 text-sm font-semibold rounded-xl hover:bg-amber-200 dark:hover:bg-amber-900/40 transition-colors"
                    >
                      <Timer size={15} />
                      Iniciar descanso (90s)
                    </button>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </Card>
        ))}
      </div>

      {/* Finish button */}
      <button
        onClick={() => setShowSummary(true)}
        className="w-full py-4 bg-gradient-to-r from-emerald-500 to-teal-600 text-white font-black text-lg rounded-2xl hover:shadow-lg hover:shadow-emerald-500/30 transition-all duration-200 flex items-center justify-center gap-2 btn-press"
      >
        <Flame size={22} />
        Terminar entrenamiento
      </button>
    </div>
  );
};
