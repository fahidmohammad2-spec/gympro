import React, { useState } from "react";
import { motion } from "framer-motion";
import { Heart, MessageCircle, Share2, UserPlus, Trophy, Users, ChevronRight } from "lucide-react";
import { Card, CardContent } from "@/components/ui/Card";
import { Badge } from "@/components/ui/Badge";
import { Progress } from "@/components/ui/Progress";

const challenges = [
  {
    id: 1, title: "30 días de entrenamiento", emoji: "🏋️", category: "Consistencia",
    progress: 12, total: 30, participants: 1284, reward: "500 XP + Medalla",
    daysLeft: 18, color: "from-indigo-500 to-purple-600"
  },
  {
    id: 2, title: "Hidratación perfecta", emoji: "💧", category: "Nutrición",
    progress: 30, total: 30, participants: 892, reward: "300 XP + Insignia",
    daysLeft: 0, color: "from-blue-500 to-cyan-600"
  },
  {
    id: 3, title: "10,000 pasos diarios", emoji: "👣", category: "Cardio",
    progress: 7, total: 14, participants: 2156, reward: "200 XP",
    daysLeft: 7, color: "from-emerald-500 to-teal-600"
  },
  {
    id: 4, title: "Proteína diaria", emoji: "🥩", category: "Nutrición",
    progress: 5, total: 21, participants: 674, reward: "400 XP",
    daysLeft: 16, color: "from-amber-500 to-orange-600"
  },
];

const friends = [
  { id: 1, name: "María García", handle: "@mariafit", avatar: "MG", lastSession: "Hace 2h", level: "Avanzado", following: true, streak: 45, color: "from-pink-400 to-rose-500" },
  { id: 2, name: "Javier López", handle: "@javierfit", avatar: "JL", lastSession: "Ayer", level: "Intermedio", following: true, streak: 8, color: "from-blue-400 to-indigo-500" },
  { id: 3, name: "Ana Martínez", handle: "@anastrength", avatar: "AM", lastSession: "Hace 3h", level: "Avanzado", following: false, streak: 62, color: "from-purple-400 to-violet-500" },
  { id: 4, name: "Carlos Ruiz", handle: "@carlosrun", avatar: "CR", lastSession: "Hace 1 día", level: "Principiante", following: false, streak: 3, color: "from-emerald-400 to-teal-500" },
  { id: 5, name: "Laura Sánchez", handle: "@laurafitness", avatar: "LS", lastSession: "Hace 5h", level: "Intermedio", following: true, streak: 21, color: "from-amber-400 to-orange-500" },
];

const feed = [
  {
    id: 1, user: "María García", avatar: "MG", time: "Hace 2 horas", avatarColor: "from-pink-400 to-rose-500",
    text: "¡Nuevo récord personal en sentadilla! 115kg × 3 reps 🎉 ¡Un año de trabajo consistente! 💪",
    workout: "Pierna Heavy",
    tags: ["#NuevoRP", "#Sentadilla", "#GymLife"],
    likes: 47, comments: 12, liked: false,
    stats: { duration: "68 min", volume: "5,240 kg" }
  },
  {
    id: 2, user: "Javier López", avatar: "JL", time: "Hace 5 horas", avatarColor: "from-blue-400 to-indigo-500",
    text: "Semana de déficit y los números siguen subiendo 📈 La paciencia es clave en este proceso.",
    workout: "Pull Day",
    tags: ["#GainzMode", "#Disciplina"],
    likes: 23, comments: 5, liked: true,
    stats: { duration: "55 min", volume: "4,120 kg" }
  },
  {
    id: 3, user: "Ana Martínez", avatar: "AM", time: "Ayer", avatarColor: "from-purple-400 to-violet-500",
    text: "Día 62 de racha 🔥🔥🔥 Quién me iba a decir hace un año que llegaría hasta aquí. No hay excusas, solo resultados.",
    workout: "Full Body",
    tags: ["#Racha62", "#SinExcusas", "#Motivación"],
    likes: 89, comments: 24, liked: false,
    stats: { duration: "45 min", volume: "3,800 kg" }
  },
];

const leaderboard = [
  { pos: 1, name: "Ana Martínez", avatar: "AM", color: "from-purple-400 to-violet-500", xp: 8420, streak: 62 },
  { pos: 2, name: "María García", avatar: "MG", color: "from-pink-400 to-rose-500", xp: 7890, streak: 45 },
  { pos: 3, name: "Carlos Andrés", avatar: "CA", color: "from-indigo-400 to-purple-500", xp: 3240, streak: 12 },
  { pos: 4, name: "Javier López", avatar: "JL", color: "from-blue-400 to-indigo-500", xp: 2980, streak: 8 },
];

export const CommunityScreen: React.FC = () => {
  const [activeTab, setActiveTab] = useState<"feed" | "challenges" | "friends" | "ranking">("feed");
  const [likedPosts, setLikedPosts] = useState<Set<number>>(new Set([2]));
  const [followedUsers, setFollowedUsers] = useState<Set<number>>(new Set([1, 2, 5]));

  const toggleLike = (id: number) => {
    setLikedPosts(prev => {
      const n = new Set(prev);
      n.has(id) ? n.delete(id) : n.add(id);
      return n;
    });
  };

  const toggleFollow = (id: number) => {
    setFollowedUsers(prev => {
      const n = new Set(prev);
      n.has(id) ? n.delete(id) : n.add(id);
      return n;
    });
  };

  return (
    <div className="space-y-5">
      {/* Tabs */}
      <div className="flex gap-1 bg-slate-100 dark:bg-slate-800 p-1 rounded-xl overflow-x-auto no-scrollbar">
        {[
          { id: "feed", label: "Feed", icon: "📱" },
          { id: "challenges", label: "Retos", icon: "🏆" },
          { id: "friends", label: "Amigos", icon: "👥" },
          { id: "ranking", label: "Ranking", icon: "🥇" },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as typeof activeTab)}
            className={`flex-1 shrink-0 flex items-center justify-center gap-1.5 py-2 px-3 text-sm font-semibold rounded-lg transition-all duration-200 ${
              activeTab === tab.id
                ? "bg-white dark:bg-slate-700 text-indigo-600 dark:text-indigo-400 shadow-sm"
                : "text-slate-500 dark:text-slate-400"
            }`}
          >
            <span className="text-base">{tab.icon}</span>
            <span>{tab.label}</span>
          </button>
        ))}
      </div>

      {/* FEED */}
      {activeTab === "feed" && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-4">
          {feed.map((post, i) => (
            <motion.div key={post.id} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.08 }}>
              <Card>
                <CardContent className="p-4 space-y-3">
                  {/* Header */}
                  <div className="flex items-center gap-3">
                    <div className={`w-10 h-10 rounded-full bg-gradient-to-br ${post.avatarColor} flex items-center justify-center text-white font-bold text-sm shrink-0`}>
                      {post.avatar}
                    </div>
                    <div className="flex-1">
                      <p className="font-bold text-sm text-slate-800 dark:text-slate-100">{post.user}</p>
                      <p className="text-xs text-slate-400">{post.time} · Completó: {post.workout}</p>
                    </div>
                    <button className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 transition-colors">
                      <ChevronRight size={16} />
                    </button>
                  </div>

                  {/* Text */}
                  <p className="text-sm text-slate-700 dark:text-slate-300 leading-relaxed">{post.text}</p>

                  {/* Tags */}
                  <div className="flex flex-wrap gap-1.5">
                    {post.tags.map(t => (
                      <span key={t} className="text-xs text-indigo-500 dark:text-indigo-400 hover:text-indigo-600 cursor-pointer">{t}</span>
                    ))}
                  </div>

                  {/* Workout stats */}
                  <div className="flex gap-3">
                    <div className="flex-1 p-2.5 bg-slate-50 dark:bg-slate-700/50 rounded-xl text-center">
                      <p className="font-bold text-sm text-slate-800 dark:text-slate-100">{post.stats.duration}</p>
                      <p className="text-[10px] text-slate-400">Duración</p>
                    </div>
                    <div className="flex-1 p-2.5 bg-slate-50 dark:bg-slate-700/50 rounded-xl text-center">
                      <p className="font-bold text-sm text-slate-800 dark:text-slate-100">{post.stats.volume}</p>
                      <p className="text-[10px] text-slate-400">Volumen</p>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex items-center gap-4 pt-1 border-t border-slate-100 dark:border-slate-700">
                    <button
                      onClick={() => toggleLike(post.id)}
                      className={`flex items-center gap-1.5 text-sm font-medium transition-colors ${
                        likedPosts.has(post.id) ? "text-rose-500" : "text-slate-400 hover:text-rose-400"
                      }`}
                    >
                      <Heart size={16} fill={likedPosts.has(post.id) ? "currentColor" : "none"} />
                      {post.likes + (likedPosts.has(post.id) && !post.liked ? 1 : likedPosts.has(post.id) && post.liked ? 0 : !likedPosts.has(post.id) && post.liked ? -1 : 0)}
                    </button>
                    <button className="flex items-center gap-1.5 text-sm font-medium text-slate-400 hover:text-indigo-400 transition-colors">
                      <MessageCircle size={16} />
                      {post.comments}
                    </button>
                    <button className="flex items-center gap-1.5 text-sm font-medium text-slate-400 hover:text-indigo-400 transition-colors ml-auto">
                      <Share2 size={16} />
                      Compartir
                    </button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </motion.div>
      )}

      {/* CHALLENGES */}
      {activeTab === "challenges" && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-3">
          {challenges.map((c, i) => (
            <motion.div key={c.id} initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.07 }}>
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center gap-3 mb-3">
                    <div className={`w-12 h-12 rounded-2xl bg-gradient-to-br ${c.color} flex items-center justify-center text-2xl shadow-md shrink-0`}>
                      {c.emoji}
                    </div>
                    <div className="flex-1">
                      <p className="font-bold text-slate-800 dark:text-slate-100">{c.title}</p>
                      <div className="flex items-center gap-2 mt-0.5">
                        <Badge variant="default" className="text-[10px]">{c.category}</Badge>
                        {c.daysLeft === 0 ? (
                          <Badge variant="success" className="text-[10px]">✓ Completado</Badge>
                        ) : (
                          <span className="text-xs text-slate-400">{c.daysLeft} días restantes</span>
                        )}
                      </div>
                    </div>
                    <div className="text-right shrink-0">
                      <p className="text-lg font-black text-slate-800 dark:text-slate-100">{c.progress}/{c.total}</p>
                      <p className="text-[10px] text-slate-400">días</p>
                    </div>
                  </div>

                  <Progress
                    value={c.progress}
                    max={c.total}
                    color={c.progress >= c.total ? "bg-emerald-500" : "bg-gradient-to-r from-indigo-500 to-purple-500"}
                    showLabel
                  />

                  <div className="flex items-center justify-between mt-3 text-xs text-slate-500 dark:text-slate-400">
                    <span className="flex items-center gap-1">
                      <Users size={12} />
                      {c.participants.toLocaleString()} participantes
                    </span>
                    <span className="flex items-center gap-1 text-amber-500 font-medium">
                      <Trophy size={12} />
                      {c.reward}
                    </span>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </motion.div>
      )}

      {/* FRIENDS */}
      {activeTab === "friends" && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-3">
          {/* Search */}
          <input
            placeholder="Buscar amigos..."
            className="w-full px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800/50 text-slate-800 dark:text-slate-100 placeholder:text-slate-400 text-sm focus:outline-none focus:border-indigo-500 transition-all"
          />

          {friends.map((friend, i) => (
            <motion.div key={friend.id} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.06 }}>
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center gap-3">
                    <div className={`w-11 h-11 rounded-full bg-gradient-to-br ${friend.color} flex items-center justify-center text-white font-bold shrink-0`}>
                      {friend.avatar}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-bold text-sm text-slate-800 dark:text-slate-100">{friend.name}</p>
                      <p className="text-xs text-slate-400">{friend.handle}</p>
                      <div className="flex items-center gap-2 mt-1">
                        <span className="text-xs text-slate-500 dark:text-slate-400">{friend.lastSession}</span>
                        <Badge variant={friend.level === "Avanzado" ? "danger" : friend.level === "Intermedio" ? "warning" : "success"} className="text-[10px]">
                          {friend.level}
                        </Badge>
                        <span className="text-xs text-orange-500 font-medium">🔥{friend.streak}</span>
                      </div>
                    </div>
                    <button
                      onClick={() => toggleFollow(friend.id)}
                      className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all shrink-0 ${
                        followedUsers.has(friend.id)
                          ? "bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300"
                          : "bg-indigo-600 text-white hover:bg-indigo-700"
                      }`}
                    >
                      {followedUsers.has(friend.id) ? "Siguiendo" : (
                        <><UserPlus size={13} /> Seguir</>
                      )}
                    </button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </motion.div>
      )}

      {/* RANKING */}
      {activeTab === "ranking" && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-4">
          {/* Filter */}
          <div className="flex gap-2">
            {["Esta semana", "Este mes", "Global"].map((f, i) => (
              <button key={f} className={`px-3 py-1.5 rounded-full text-xs font-medium transition-all ${
                i === 1 ? "bg-indigo-600 text-white" : "bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-400 border border-slate-200 dark:border-slate-700"
              }`}>{f}</button>
            ))}
          </div>

          {/* Podium */}
          <div className="grid grid-cols-3 gap-3 mb-2">
            {[leaderboard[1], leaderboard[0], leaderboard[2]].map((user, i) => {
              const positions = [2, 1, 3];
              const pos = positions[i];
              const medals = ["🥈", "🥇", "🥉"];
              const heights = ["h-20", "h-28", "h-16"];
              return (
                <div key={user.pos} className="flex flex-col items-center gap-2">
                  <div className={`w-12 h-12 rounded-full bg-gradient-to-br ${user.color} flex items-center justify-center text-white font-bold text-sm border-2 ${pos === 1 ? "border-amber-400 shadow-lg shadow-amber-400/30" : "border-slate-200 dark:border-slate-600"}`}>
                    {user.avatar}
                  </div>
                  <p className="text-xs font-bold text-slate-800 dark:text-slate-100 text-center leading-tight">{user.name.split(" ")[0]}</p>
                  <div className={`w-full ${heights[i]} rounded-t-xl flex flex-col items-center justify-center ${
                    pos === 1 ? "bg-amber-400" : pos === 2 ? "bg-slate-300 dark:bg-slate-600" : "bg-orange-300 dark:bg-orange-700"
                  } gap-1`}>
                    <span className="text-xl">{medals[i]}</span>
                    <span className="text-xs font-black text-white">{pos}º</span>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Full list */}
          <div className="space-y-2">
            {leaderboard.map((user) => (
              <div key={user.pos} className={`flex items-center gap-3 p-3 rounded-xl ${user.name === "Carlos Andrés" ? "bg-indigo-50 dark:bg-indigo-950/30 border border-indigo-100 dark:border-indigo-900/40" : "bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700"}`}>
                <span className="w-8 text-center font-black text-slate-400 dark:text-slate-500 text-sm">#{user.pos}</span>
                <div className={`w-9 h-9 rounded-full bg-gradient-to-br ${user.color} flex items-center justify-center text-white font-bold text-xs shrink-0`}>
                  {user.avatar}
                </div>
                <div className="flex-1">
                  <p className="text-sm font-bold text-slate-800 dark:text-slate-100">{user.name}</p>
                  <p className="text-xs text-slate-400">🔥 {user.streak} días de racha</p>
                </div>
                <div className="text-right">
                  <p className="font-black text-indigo-600 dark:text-indigo-400">{user.xp.toLocaleString()} XP</p>
                </div>
              </div>
            ))}
          </div>
        </motion.div>
      )}
    </div>
  );
};
