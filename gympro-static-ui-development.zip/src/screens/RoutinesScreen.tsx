import React, { useState } from "react";
import { motion } from "framer-motion";
import {
  Plus, Copy, Edit2, Trash2, Dumbbell, Clock, Calendar,
  ChevronRight, Search, MoreVertical, PlayCircle
} from "lucide-react";
import { Card, CardContent } from "@/components/ui/Card";
import { Badge } from "@/components/ui/Badge";
import { Modal } from "@/components/ui/Modal";
import { cn } from "@/utils/cn";

const routines = [
  {
    id: 1, name: "Pecho & Tríceps", exercises: 6, duration: 60, lastDone: "Ayer",
    level: "Intermedio", color: "from-blue-500 to-indigo-600", emoji: "💪",
    tags: ["Push", "Fuerza"],
    exerciseList: ["Press Banca", "Press Inclinado", "Aperturas", "Fondos", "Press Francés", "Extensiones"]
  },
  {
    id: 2, name: "Espalda & Bíceps", exercises: 7, duration: 65, lastDone: "Hace 2 días",
    level: "Intermedio", color: "from-purple-500 to-pink-600", emoji: "🏋️",
    tags: ["Pull", "Fuerza"],
    exerciseList: ["Dominadas", "Remo Barra", "Jalón Polea", "Remo Mancuerna", "Curl Bíceps", "Curl Martillo", "Face Pull"]
  },
  {
    id: 3, name: "Rutina de Pierna", exercises: 8, duration: 75, lastDone: "Hace 3 días",
    level: "Avanzado", color: "from-emerald-500 to-teal-600", emoji: "🦵",
    tags: ["Legs", "Fuerza"],
    exerciseList: ["Sentadilla", "Prensa", "Extensiones", "Curl Femoral", "Hip Thrust", "Elevación Gemelos", "Zancadas", "Sentadilla Búlgara"]
  },
  {
    id: 4, name: "Full Body Express", exercises: 5, duration: 35, lastDone: "Hace 5 días",
    level: "Principiante", color: "from-amber-500 to-orange-600", emoji: "⚡",
    tags: ["Full Body", "HIIT"],
    exerciseList: ["Sentadilla", "Press Banca", "Peso Muerto", "Plancha", "Press Militar"]
  },
  {
    id: 5, name: "Shoulders & Abs", exercises: 6, duration: 45, lastDone: "Hace 1 semana",
    level: "Intermedio", color: "from-rose-500 to-red-600", emoji: "🎯",
    tags: ["Push", "Core"],
    exerciseList: ["Press Militar", "Elevaciones Laterales", "Pájaros", "Crunch", "Plancha", "Russian Twist"]
  },
];

const exerciseOptions = [
  "Press de Banca", "Sentadilla", "Peso Muerto", "Dominadas", "Press Militar",
  "Curl Bíceps", "Extensiones Tríceps", "Plancha", "Hip Thrust", "Remo con Barra",
  "Fondos", "Zancadas", "Press Inclinado", "Jalón Polea", "Elevaciones Laterales",
];

export const RoutinesScreen: React.FC<{ onNavigate: (page: string) => void }> = ({ onNavigate }) => {
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showDetailModal, setShowDetailModal] = useState<typeof routines[0] | null>(null);
  const [selectedExercises, setSelectedExercises] = useState<string[]>(["Press de Banca", "Sentadilla"]);
  const [exerciseSearch, setExerciseSearch] = useState("");

  const toggleExercise = (name: string) => {
    setSelectedExercises(prev =>
      prev.includes(name) ? prev.filter(e => e !== name) : [...prev, name]
    );
  };

  const filteredExOptions = exerciseOptions.filter(e =>
    e.toLowerCase().includes(exerciseSearch.toLowerCase())
  );

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="font-black text-slate-800 dark:text-slate-100 text-lg">Mis Rutinas</h2>
          <p className="text-sm text-slate-500 dark:text-slate-400">{routines.length} rutinas guardadas</p>
        </div>
        <button
          onClick={() => setShowCreateModal(true)}
          className="flex items-center gap-2 px-4 py-2.5 bg-indigo-600 text-white rounded-xl text-sm font-bold hover:bg-indigo-700 transition-colors shadow-md btn-press"
        >
          <Plus size={16} />
          Nueva rutina
        </button>
      </div>

      {/* Routines list */}
      <div className="space-y-3">
        {routines.map((routine, i) => (
          <motion.div
            key={routine.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.07 }}
          >
            <Card hover>
              <CardContent className="p-4">
                <div className="flex items-center gap-4">
                  {/* Emoji/Icon */}
                  <div className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${routine.color} flex items-center justify-center shadow-md shrink-0`}>
                    <span className="text-2xl">{routine.emoji}</span>
                  </div>

                  {/* Info */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-0.5">
                      <p className="font-bold text-slate-800 dark:text-slate-100">{routine.name}</p>
                      {routine.tags.map(t => (
                        <Badge key={t} variant="info" className="text-[10px] hidden sm:inline-flex">{t}</Badge>
                      ))}
                    </div>
                    <div className="flex items-center gap-3 text-xs text-slate-500 dark:text-slate-400">
                      <span className="flex items-center gap-1">
                        <Dumbbell size={11} />
                        {routine.exercises} ejercicios
                      </span>
                      <span className="flex items-center gap-1">
                        <Clock size={11} />
                        ~{routine.duration} min
                      </span>
                      <span className="flex items-center gap-1">
                        <Calendar size={11} />
                        {routine.lastDone}
                      </span>
                    </div>
                    <Badge
                      className="mt-1.5 text-[10px]"
                      variant={routine.level === "Avanzado" ? "danger" : routine.level === "Intermedio" ? "warning" : "success"}
                    >
                      {routine.level}
                    </Badge>
                  </div>

                  {/* Actions */}
                  <div className="flex items-center gap-1 shrink-0">
                    <button
                      onClick={() => onNavigate("workout")}
                      className="p-2 text-indigo-500 hover:bg-indigo-50 dark:hover:bg-indigo-950/30 rounded-xl transition-colors"
                      title="Iniciar"
                    >
                      <PlayCircle size={20} />
                    </button>
                    <button
                      onClick={() => setShowDetailModal(routine)}
                      className="p-2 text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-xl transition-colors"
                      title="Ver detalles"
                    >
                      <ChevronRight size={18} />
                    </button>
                    <div className="relative group">
                      <button className="p-2 text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-xl transition-colors">
                        <MoreVertical size={16} />
                      </button>
                      <div className="absolute right-0 top-10 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl shadow-lg py-1 w-36 z-10 opacity-0 group-hover:opacity-100 pointer-events-none group-hover:pointer-events-auto transition-opacity">
                        <button className="w-full flex items-center gap-2 px-3 py-2 text-sm text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-700">
                          <Edit2 size={14} /> Editar
                        </button>
                        <button className="w-full flex items-center gap-2 px-3 py-2 text-sm text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-700">
                          <Copy size={14} /> Duplicar
                        </button>
                        <button className="w-full flex items-center gap-2 px-3 py-2 text-sm text-red-500 hover:bg-red-50 dark:hover:bg-red-950/30">
                          <Trash2 size={14} /> Eliminar
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      {/* Create routine modal */}
      <Modal
        open={showCreateModal}
        onClose={() => setShowCreateModal(false)}
        title="Crear nueva rutina"
        size="xl"
      >
        <div className="space-y-5">
          {/* Name */}
          <div>
            <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">Nombre de la rutina *</label>
            <input
              placeholder="Ej: Pecho & Tríceps"
              defaultValue="Mi nueva rutina"
              className="w-full px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-600 bg-white dark:bg-slate-700/50 text-slate-800 dark:text-slate-100 text-sm focus:outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20"
            />
          </div>

          {/* Description */}
          <div>
            <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">Descripción</label>
            <textarea
              rows={2}
              placeholder="Describe tu rutina..."
              className="w-full px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-600 bg-white dark:bg-slate-700/50 text-slate-800 dark:text-slate-100 text-sm focus:outline-none focus:border-indigo-500 resize-none"
              defaultValue="Rutina enfocada en el desarrollo de la parte superior del cuerpo."
            />
          </div>

          {/* Level + Days */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">Nivel</label>
              <select className="w-full px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-600 bg-white dark:bg-slate-700/50 text-slate-800 dark:text-slate-100 text-sm focus:outline-none focus:border-indigo-500">
                <option>Principiante</option>
                <option selected>Intermedio</option>
                <option>Avanzado</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">Días programados</label>
              <div className="flex gap-1">
                {["L","M","X","J","V","S","D"].map((d, i) => (
                  <button key={d} className={cn(
                    "flex-1 h-9 text-xs font-bold rounded-lg transition-all",
                    [0, 2, 4].includes(i)
                      ? "bg-indigo-600 text-white"
                      : "bg-slate-100 dark:bg-slate-700 text-slate-500 dark:text-slate-400"
                  )}>{d}</button>
                ))}
              </div>
            </div>
          </div>

          {/* Exercise search */}
          <div>
            <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">
              Ejercicios ({selectedExercises.length} seleccionados)
            </label>
            <div className="relative mb-2">
              <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                placeholder="Buscar ejercicio..."
                value={exerciseSearch}
                onChange={e => setExerciseSearch(e.target.value)}
                className="w-full pl-9 pr-4 py-2 rounded-xl border border-slate-200 dark:border-slate-600 bg-white dark:bg-slate-700/50 text-slate-800 dark:text-slate-100 text-sm focus:outline-none focus:border-indigo-500"
              />
            </div>
            <div className="max-h-36 overflow-y-auto space-y-1 no-scrollbar">
              {filteredExOptions.map((ex) => (
                <button
                  key={ex}
                  onClick={() => toggleExercise(ex)}
                  className={cn(
                    "w-full flex items-center justify-between px-3 py-2 rounded-xl text-sm transition-all",
                    selectedExercises.includes(ex)
                      ? "bg-indigo-50 dark:bg-indigo-950/30 text-indigo-600 dark:text-indigo-400 font-medium"
                      : "hover:bg-slate-50 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300"
                  )}
                >
                  <span>{ex}</span>
                  {selectedExercises.includes(ex) && (
                    <span className="w-4 h-4 rounded-full bg-indigo-600 flex items-center justify-center">
                      <span className="text-white text-[10px]">✓</span>
                    </span>
                  )}
                </button>
              ))}
            </div>
          </div>

          {/* Selected exercises config */}
          {selectedExercises.length > 0 && (
            <div>
              <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">
                Configuración de series
              </label>
              <div className="space-y-2">
                {selectedExercises.map((ex, i) => (
                  <div key={ex} className="flex items-center gap-2 p-3 bg-slate-50 dark:bg-slate-700/50 rounded-xl">
                    <span className="w-5 h-5 rounded-full bg-indigo-100 dark:bg-indigo-900/50 text-indigo-600 dark:text-indigo-400 flex items-center justify-center text-xs font-bold shrink-0">
                      {i + 1}
                    </span>
                    <span className="flex-1 text-sm font-medium text-slate-700 dark:text-slate-300 truncate">{ex}</span>
                    <div className="flex items-center gap-1 text-xs">
                      <input defaultValue="4" className="w-8 text-center py-1 rounded-lg border border-slate-200 dark:border-slate-600 bg-white dark:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs focus:outline-none focus:border-indigo-500" />
                      <span className="text-slate-400">x</span>
                      <input defaultValue="10" className="w-8 text-center py-1 rounded-lg border border-slate-200 dark:border-slate-600 bg-white dark:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs focus:outline-none focus:border-indigo-500" />
                      <span className="text-slate-400">reps</span>
                      <input defaultValue="90" className="w-10 text-center py-1 rounded-lg border border-slate-200 dark:border-slate-600 bg-white dark:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs focus:outline-none focus:border-indigo-500" />
                      <span className="text-slate-400">s</span>
                    </div>
                    <button onClick={() => toggleExercise(ex)} className="p-1 text-red-400 hover:text-red-600 transition-colors">
                      <Trash2 size={13} />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Actions */}
          <div className="flex gap-3 pt-2 border-t border-slate-100 dark:border-slate-700">
            <button
              onClick={() => setShowCreateModal(false)}
              className="flex-1 py-3 border-2 border-slate-200 dark:border-slate-700 rounded-xl text-slate-600 dark:text-slate-300 font-semibold hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors"
            >
              Cancelar
            </button>
            <button
              onClick={() => setShowCreateModal(false)}
              className="flex-1 py-3 bg-indigo-600 text-white font-bold rounded-xl hover:bg-indigo-700 transition-colors flex items-center justify-center gap-2"
            >
              <Plus size={16} />
              Crear rutina
            </button>
          </div>
        </div>
      </Modal>

      {/* Routine detail modal */}
      <Modal
        open={!!showDetailModal}
        onClose={() => setShowDetailModal(null)}
        title={showDetailModal?.name}
        size="lg"
      >
        {showDetailModal && (
          <div className="space-y-4">
            <div className={`h-24 rounded-2xl bg-gradient-to-br ${showDetailModal.color} flex items-center justify-center`}>
              <span className="text-5xl">{showDetailModal.emoji}</span>
            </div>
            <div className="grid grid-cols-3 gap-3">
              {[
                { label: "Ejercicios", value: showDetailModal.exercises },
                { label: "Duración aprox.", value: `${showDetailModal.duration} min` },
                { label: "Último entreno", value: showDetailModal.lastDone },
              ].map(s => (
                <div key={s.label} className="text-center p-3 bg-slate-50 dark:bg-slate-700/50 rounded-xl">
                  <p className="font-black text-slate-800 dark:text-slate-100">{s.value}</p>
                  <p className="text-[10px] text-slate-400">{s.label}</p>
                </div>
              ))}
            </div>
            <div>
              <p className="text-sm font-bold text-slate-700 dark:text-slate-300 mb-2">Lista de ejercicios</p>
              <div className="space-y-2">
                {showDetailModal.exerciseList.map((ex, i) => (
                  <div key={ex} className="flex items-center gap-3 p-2.5 bg-slate-50 dark:bg-slate-700/50 rounded-xl">
                    <span className="w-6 h-6 rounded-lg bg-indigo-100 dark:bg-indigo-900/50 text-indigo-600 dark:text-indigo-400 flex items-center justify-center text-xs font-bold">
                      {i + 1}
                    </span>
                    <span className="flex-1 text-sm text-slate-700 dark:text-slate-300">{ex}</span>
                    <span className="text-xs text-slate-400">4×10</span>
                  </div>
                ))}
              </div>
            </div>
            <button
              onClick={() => { setShowDetailModal(null); onNavigate("workout"); }}
              className="w-full py-3 bg-indigo-600 text-white font-bold rounded-xl hover:bg-indigo-700 transition-colors flex items-center justify-center gap-2"
            >
              <PlayCircle size={18} />
              Iniciar esta rutina
            </button>
          </div>
        )}
      </Modal>
    </div>
  );
};
