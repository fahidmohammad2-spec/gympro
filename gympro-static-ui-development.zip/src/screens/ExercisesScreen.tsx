import React, { useState } from "react";
import { motion } from "framer-motion";
import { Search, Filter, X, Play, Info, Dumbbell, ChevronRight, Star } from "lucide-react";
import { Card, CardContent } from "@/components/ui/Card";
import { Badge } from "@/components/ui/Badge";
import { Modal } from "@/components/ui/Modal";
import { cn } from "@/utils/cn";

const muscleGroups = ["Todos", "Pecho", "Espalda", "Piernas", "Hombros", "Bíceps", "Tríceps", "Abdomen", "Glúteos"];

const exercises = [
  { id: 1, name: "Press de Banca", muscle: "Pecho", secondary: ["Tríceps", "Hombros"], level: "Intermedio", equipment: "Barra", emoji: "🏋️", rating: 4.8, type: "Fuerza" },
  { id: 2, name: "Sentadilla", muscle: "Piernas", secondary: ["Glúteos", "Core"], level: "Principiante", equipment: "Barra", emoji: "🦵", rating: 5.0, type: "Fuerza" },
  { id: 3, name: "Peso Muerto", muscle: "Espalda", secondary: ["Piernas", "Glúteos"], level: "Avanzado", equipment: "Barra", emoji: "⚡", rating: 4.9, type: "Fuerza" },
  { id: 4, name: "Dominadas", muscle: "Espalda", secondary: ["Bíceps"], level: "Intermedio", equipment: "Barra Fija", emoji: "💪", rating: 4.7, type: "Peso corporal" },
  { id: 5, name: "Press Militar", muscle: "Hombros", secondary: ["Tríceps"], level: "Intermedio", equipment: "Barra/Mancuernas", emoji: "🎯", rating: 4.6, type: "Fuerza" },
  { id: 6, name: "Curl Bíceps", muscle: "Bíceps", secondary: ["Antebrazos"], level: "Principiante", equipment: "Mancuernas", emoji: "💪", rating: 4.5, type: "Fuerza" },
  { id: 7, name: "Extensiones Tríceps", muscle: "Tríceps", secondary: [], level: "Principiante", equipment: "Cuerda", emoji: "🦾", rating: 4.4, type: "Fuerza" },
  { id: 8, name: "Plancha", muscle: "Abdomen", secondary: ["Core", "Hombros"], level: "Principiante", equipment: "Sin equipo", emoji: "🧘", rating: 4.6, type: "Isométrico" },
  { id: 9, name: "Hip Thrust", muscle: "Glúteos", secondary: ["Femorales"], level: "Intermedio", equipment: "Barra", emoji: "🍑", rating: 4.7, type: "Fuerza" },
  { id: 10, name: "Remo con Barra", muscle: "Espalda", secondary: ["Bíceps", "Core"], level: "Intermedio", equipment: "Barra", emoji: "🚣", rating: 4.6, type: "Fuerza" },
  { id: 11, name: "Fondos en Paralelas", muscle: "Tríceps", secondary: ["Pecho", "Hombros"], level: "Intermedio", equipment: "Paralelas", emoji: "🏅", rating: 4.5, type: "Peso corporal" },
  { id: 12, name: "Zancadas", muscle: "Piernas", secondary: ["Glúteos"], level: "Principiante", equipment: "Mancuernas", emoji: "🦿", rating: 4.3, type: "Fuerza" },
];

const levelColors: Record<string, string> = {
  "Principiante": "success",
  "Intermedio": "warning",
  "Avanzado": "danger",
};

export const ExercisesScreen: React.FC = () => {
  const [search, setSearch] = useState("");
  const [selectedMuscle, setSelectedMuscle] = useState("Todos");
  const [selectedExercise, setSelectedExercise] = useState<typeof exercises[0] | null>(null);

  const filtered = exercises.filter(e => {
    const matchSearch = e.name.toLowerCase().includes(search.toLowerCase());
    const matchMuscle = selectedMuscle === "Todos" || e.muscle === selectedMuscle;
    return matchSearch && matchMuscle;
  });

  return (
    <div className="space-y-5">
      {/* Search + Filter */}
      <div className="space-y-3">
        <div className="relative">
          <Search size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Buscar ejercicio..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="w-full pl-10 pr-10 py-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800/50 text-slate-800 dark:text-slate-100 placeholder:text-slate-400 text-sm focus:outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 transition-all"
          />
          {search && (
            <button onClick={() => setSearch("")} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200">
              <X size={16} />
            </button>
          )}
        </div>

        {/* Muscle chips */}
        <div className="flex gap-2 overflow-x-auto no-scrollbar pb-1">
          {muscleGroups.map((group) => (
            <button
              key={group}
              onClick={() => setSelectedMuscle(group)}
              className={cn(
                "shrink-0 px-4 py-1.5 rounded-full text-sm font-medium transition-all duration-200",
                selectedMuscle === group
                  ? "bg-indigo-600 text-white shadow-md shadow-indigo-500/20"
                  : "bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-400 border border-slate-200 dark:border-slate-700 hover:border-indigo-300 dark:hover:border-indigo-700"
              )}
            >
              {group}
            </button>
          ))}
        </div>

        {/* Results count */}
        <div className="flex items-center justify-between">
          <p className="text-sm text-slate-500 dark:text-slate-400">
            <span className="font-semibold text-slate-700 dark:text-slate-200">{filtered.length}</span> ejercicios encontrados
          </p>
          <button className="flex items-center gap-1.5 text-sm text-indigo-500 hover:text-indigo-600 font-medium">
            <Filter size={14} />
            Más filtros
          </button>
        </div>
      </div>

      {/* Exercise grid */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
        {filtered.map((exercise, i) => (
          <motion.div
            key={exercise.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.04, duration: 0.3 }}
          >
            <Card hover className="overflow-hidden" onClick={() => setSelectedExercise(exercise)}>
              {/* Placeholder image */}
              <div className="h-28 bg-gradient-to-br from-slate-100 to-slate-200 dark:from-slate-700 dark:to-slate-800 flex flex-col items-center justify-center relative">
                <span className="text-4xl mb-1">{exercise.emoji}</span>
                <div className="absolute top-2 right-2">
                  <Badge variant={levelColors[exercise.level] as "success" | "warning" | "danger"} className="text-[10px]">
                    {exercise.level}
                  </Badge>
                </div>
                <div className="absolute bottom-0 left-0 right-0 h-8 bg-gradient-to-t from-white/50 dark:from-slate-800/50 to-transparent" />
              </div>
              <CardContent className="p-3">
                <p className="font-bold text-sm text-slate-800 dark:text-slate-100 leading-tight">{exercise.name}</p>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">{exercise.muscle}</p>
                <div className="flex items-center justify-between mt-2">
                  <span className="text-xs text-amber-500 flex items-center gap-0.5">
                    <Star size={10} fill="currentColor" />
                    {exercise.rating}
                  </span>
                  <span className="text-xs text-slate-400 dark:text-slate-500">{exercise.equipment}</span>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      {/* Exercise detail modal */}
      <Modal
        open={!!selectedExercise}
        onClose={() => setSelectedExercise(null)}
        size="lg"
        title={selectedExercise?.name}
      >
        {selectedExercise && (
          <div className="space-y-5">
            {/* Hero */}
            <div className="h-40 bg-gradient-to-br from-indigo-50 to-purple-50 dark:from-indigo-950/30 dark:to-purple-950/30 rounded-xl flex flex-col items-center justify-center border border-indigo-100 dark:border-indigo-900/40">
              <span className="text-6xl">{selectedExercise.emoji}</span>
              <Badge variant="info" className="mt-3">{selectedExercise.type}</Badge>
            </div>

            {/* Info grid */}
            <div className="grid grid-cols-3 gap-3">
              {[
                { label: "Músculo principal", value: selectedExercise.muscle },
                { label: "Nivel", value: selectedExercise.level },
                { label: "Equipo", value: selectedExercise.equipment },
              ].map((info) => (
                <div key={info.label} className="p-3 bg-slate-50 dark:bg-slate-700/50 rounded-xl text-center">
                  <p className="text-[10px] text-slate-400 mb-1">{info.label}</p>
                  <p className="text-xs font-bold text-slate-700 dark:text-slate-200">{info.value}</p>
                </div>
              ))}
            </div>

            {/* Secondary muscles */}
            {selectedExercise.secondary.length > 0 && (
              <div>
                <p className="text-sm font-bold text-slate-700 dark:text-slate-300 mb-2">Músculos secundarios</p>
                <div className="flex gap-2 flex-wrap">
                  {selectedExercise.secondary.map(m => (
                    <Badge key={m} variant="default">{m}</Badge>
                  ))}
                </div>
              </div>
            )}

            {/* Description */}
            <div>
              <p className="text-sm font-bold text-slate-700 dark:text-slate-300 mb-2 flex items-center gap-2">
                <Info size={14} />
                Descripción y técnica
              </p>
              <p className="text-sm text-slate-600 dark:text-slate-400 leading-relaxed">
                {selectedExercise.name === "Press de Banca"
                  ? "El press de banca es uno de los ejercicios más completos para desarrollar la fuerza y masa del pecho. Acuéstate en el banco con los pies apoyados en el suelo, agarra la barra con un agarre ligeramente más ancho que los hombros. Baja la barra de forma controlada hasta rozar el pecho y empuja explosivamente hacia arriba."
                  : `El ejercicio de ${selectedExercise.name} es fundamental para desarrollar el ${selectedExercise.muscle}. Mantén una técnica correcta en todo momento, controlando el movimiento tanto en la fase concéntrica como excéntrica. Asegúrate de calentar adecuadamente antes de realizar series de trabajo.`}
              </p>
            </div>

            {/* Tips */}
            <div className="bg-amber-50 dark:bg-amber-950/30 rounded-xl p-4 border border-amber-100 dark:border-amber-900/40">
              <p className="text-sm font-bold text-amber-700 dark:text-amber-400 mb-2">💡 Consejos</p>
              <ul className="space-y-1.5">
                {[
                  "Mantén la espalda en posición neutra durante todo el movimiento",
                  "Respira correctamente: exhala en el esfuerzo, inhala en el retorno",
                  "Comienza con pesos que te permitan hacer la técnica perfecta",
                ].map((tip, i) => (
                  <li key={i} className="text-xs text-amber-700 dark:text-amber-400 flex items-start gap-2">
                    <span className="shrink-0 mt-0.5">•</span>
                    {tip}
                  </li>
                ))}
              </ul>
            </div>

            {/* Video placeholder */}
            <div>
              <p className="text-sm font-bold text-slate-700 dark:text-slate-300 mb-2 flex items-center gap-2">
                <Play size={14} />
                Video tutorial
              </p>
              <div className="aspect-video bg-slate-100 dark:bg-slate-700 rounded-xl flex flex-col items-center justify-center border border-slate-200 dark:border-slate-600">
                <div className="w-14 h-14 rounded-full bg-indigo-600 flex items-center justify-center shadow-lg mb-2">
                  <Play size={24} className="text-white ml-1" fill="white" />
                </div>
                <p className="text-xs text-slate-400 dark:text-slate-500">Video tutorial disponible</p>
                <p className="text-xs text-slate-300 dark:text-slate-600">Haz clic para reproducir</p>
              </div>
            </div>

            {/* CTA */}
            <div className="flex gap-3">
              <button className="flex-1 py-3 bg-indigo-600 text-white font-bold rounded-xl hover:bg-indigo-700 transition-colors flex items-center justify-center gap-2">
                <Dumbbell size={16} />
                Añadir a rutina
              </button>
              <button className="px-4 py-3 border-2 border-slate-200 dark:border-slate-700 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors">
                <ChevronRight size={18} />
              </button>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
};
