import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ChevronDown, ChevronUp, Calendar, Clock, Dumbbell, TrendingUp, Flame } from "lucide-react";
import { Card, CardContent } from "@/components/ui/Card";

const historyData = [
  {
    id: 1, date: "Hoy, 15 Ene", routine: "Rutina de Pierna", duration: "47 min",
    volume: "3,240 kg", exercises: 4, sets: 14, calories: 387,
    color: "from-emerald-500 to-teal-600", emoji: "🦵",
    details: [
      { name: "Sentadilla", sets: [{ w: 80, r: 10 }, { w: 85, r: 8 }, { w: 85, r: 8 }, { w: 90, r: 6 }] },
      { name: "Prensa de Pierna", sets: [{ w: 120, r: 12 }, { w: 130, r: 10 }, { w: 130, r: 10 }] },
      { name: "Extensiones", sets: [{ w: 40, r: 15 }, { w: 40, r: 15 }, { w: 45, r: 12 }] },
      { name: "Hip Thrust", sets: [{ w: 100, r: 10 }, { w: 100, r: 10 }, { w: 105, r: 8 }] },
    ]
  },
  {
    id: 2, date: "Ayer, 14 Ene", routine: "Pecho & Tríceps", duration: "55 min",
    volume: "4,120 kg", exercises: 6, sets: 18, calories: 412,
    color: "from-blue-500 to-indigo-600", emoji: "💪",
    details: [
      { name: "Press de Banca", sets: [{ w: 90, r: 8 }, { w: 95, r: 6 }, { w: 100, r: 5 }, { w: 95, r: 6 }] },
      { name: "Press Inclinado", sets: [{ w: 70, r: 10 }, { w: 75, r: 8 }, { w: 75, r: 8 }] },
      { name: "Aperturas Mancuernas", sets: [{ w: 20, r: 12 }, { w: 20, r: 12 }, { w: 22, r: 10 }] },
      { name: "Fondos", sets: [{ w: 0, r: 15 }, { w: 0, r: 12 }, { w: 10, r: 10 }] },
      { name: "Press Francés", sets: [{ w: 30, r: 12 }, { w: 32, r: 10 }, { w: 32, r: 10 }] },
      { name: "Extensiones Cuerda", sets: [{ w: 25, r: 15 }, { w: 27, r: 12 }] },
    ]
  },
  {
    id: 3, date: "13 Ene", routine: "Espalda & Bíceps", duration: "62 min",
    volume: "5,540 kg", exercises: 7, sets: 21, calories: 445,
    color: "from-purple-500 to-pink-600", emoji: "🏋️",
    details: [
      { name: "Dominadas", sets: [{ w: 0, r: 10 }, { w: 10, r: 8 }, { w: 10, r: 7 }, { w: 10, r: 6 }] },
      { name: "Remo con Barra", sets: [{ w: 80, r: 8 }, { w: 85, r: 8 }, { w: 85, r: 7 }] },
      { name: "Jalón Polea", sets: [{ w: 65, r: 12 }, { w: 70, r: 10 }, { w: 70, r: 10 }] },
      { name: "Curl Bíceps Barra", sets: [{ w: 40, r: 10 }, { w: 42, r: 8 }, { w: 40, r: 10 }] },
      { name: "Curl Martillo", sets: [{ w: 16, r: 12 }, { w: 18, r: 10 }, { w: 18, r: 10 }] },
    ]
  },
  {
    id: 4, date: "11 Ene", routine: "Full Body Express", duration: "38 min",
    volume: "2,890 kg", exercises: 5, sets: 15, calories: 298,
    color: "from-amber-500 to-orange-600", emoji: "⚡",
    details: [
      { name: "Sentadilla", sets: [{ w: 70, r: 12 }, { w: 75, r: 10 }, { w: 75, r: 10 }] },
      { name: "Press Banca", sets: [{ w: 80, r: 10 }, { w: 85, r: 8 }, { w: 85, r: 8 }] },
      { name: "Peso Muerto", sets: [{ w: 100, r: 8 }, { w: 105, r: 6 }, { w: 105, r: 6 }] },
    ]
  },
  {
    id: 5, date: "9 Ene", routine: "Hombros & Abdomen", duration: "50 min",
    volume: "2,140 kg", exercises: 6, sets: 18, calories: 356,
    color: "from-rose-500 to-red-600", emoji: "🎯",
    details: [
      { name: "Press Militar", sets: [{ w: 60, r: 10 }, { w: 65, r: 8 }, { w: 65, r: 8 }, { w: 60, r: 10 }] },
      { name: "Elevaciones Laterales", sets: [{ w: 12, r: 15 }, { w: 14, r: 12 }, { w: 14, r: 12 }] },
      { name: "Plancha", sets: [{ w: 0, r: 60 }, { w: 0, r: 60 }, { w: 0, r: 75 }] },
    ]
  },
];

export const HistoryScreen: React.FC = () => {
  const [expandedId, setExpandedId] = useState<number | null>(null);

  return (
    <div className="space-y-5">
      {/* Summary stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {[
          { icon: <Dumbbell size={18} className="text-indigo-500" />, label: "Sesiones este mes", value: "12", bg: "bg-indigo-50 dark:bg-indigo-950/30" },
          { icon: <Clock size={18} className="text-blue-500" />, label: "Tiempo total", value: "9h 42m", bg: "bg-blue-50 dark:bg-blue-950/30" },
          { icon: <TrendingUp size={18} className="text-emerald-500" />, label: "Volumen total", value: "47t", bg: "bg-emerald-50 dark:bg-emerald-950/30" },
          { icon: <Flame size={18} className="text-orange-500" />, label: "Calorías quemadas", value: "5,840", bg: "bg-orange-50 dark:bg-orange-950/30" },
        ].map((stat) => (
          <Card key={stat.label}>
            <CardContent className="p-4">
              <div className={`w-9 h-9 rounded-xl ${stat.bg} flex items-center justify-center mb-2`}>
                {stat.icon}
              </div>
              <p className="text-xl font-black text-slate-800 dark:text-slate-100">{stat.value}</p>
              <p className="text-xs text-slate-500 dark:text-slate-400 leading-tight">{stat.label}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Filter tabs */}
      <div className="flex gap-2">
        {["Semana", "Mes", "Año", "Todo"].map((f, i) => (
          <button key={f} className={`px-4 py-1.5 rounded-full text-sm font-medium transition-all ${
            i === 0
              ? "bg-indigo-600 text-white shadow-md"
              : "bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-400 border border-slate-200 dark:border-slate-700 hover:border-indigo-300"
          }`}>{f}</button>
        ))}
      </div>

      {/* History list */}
      <div className="space-y-3">
        {historyData.map((session, i) => (
          <motion.div
            key={session.id}
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.07 }}
          >
            <Card>
              {/* Header row */}
              <button
                onClick={() => setExpandedId(expandedId === session.id ? null : session.id)}
                className="w-full p-4 flex items-center gap-3 hover:bg-slate-50 dark:hover:bg-slate-700/30 transition-colors rounded-2xl text-left"
              >
                <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${session.color} flex items-center justify-center shadow-md shrink-0`}>
                  <span className="text-xl">{session.emoji}</span>
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-bold text-slate-800 dark:text-slate-100 truncate">{session.routine}</p>
                  <div className="flex items-center gap-3 text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                    <span className="flex items-center gap-1"><Calendar size={11} />{session.date}</span>
                    <span className="flex items-center gap-1"><Clock size={11} />{session.duration}</span>
                    <span className="flex items-center gap-1"><Dumbbell size={11} />{session.exercises} ej.</span>
                  </div>
                </div>
                <div className="text-right shrink-0">
                  <p className="font-bold text-sm text-indigo-600 dark:text-indigo-400">{session.volume}</p>
                  <p className="text-xs text-slate-400">volumen</p>
                </div>
                <div className="ml-2 text-slate-400">
                  {expandedId === session.id ? <ChevronUp size={18} /> : <ChevronDown size={18} />}
                </div>
              </button>

              {/* Expandable details */}
              <AnimatePresence>
                {expandedId === session.id && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: "auto", opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    className="overflow-hidden"
                  >
                    <div className="px-4 pb-4 space-y-3">
                      <div className="h-px bg-slate-100 dark:bg-slate-700" />

                      {/* Quick stats */}
                      <div className="grid grid-cols-3 gap-2">
                        {[
                          { label: "Series", value: session.sets },
                          { label: "Calorías", value: `${session.calories} kcal` },
                          { label: "Ejercicios", value: session.exercises },
                        ].map(s => (
                          <div key={s.label} className="text-center p-2 bg-slate-50 dark:bg-slate-700/50 rounded-xl">
                            <p className="font-bold text-sm text-slate-800 dark:text-slate-100">{s.value}</p>
                            <p className="text-[10px] text-slate-400">{s.label}</p>
                          </div>
                        ))}
                      </div>

                      {/* Exercises breakdown */}
                      <div className="space-y-2">
                        {session.details.map((ex) => (
                          <div key={ex.name} className="p-3 bg-slate-50 dark:bg-slate-700/50 rounded-xl">
                            <p className="font-semibold text-sm text-slate-800 dark:text-slate-100 mb-2">{ex.name}</p>
                            <div className="flex flex-wrap gap-1.5">
                              {ex.sets.map((set, si) => (
                                <span key={si} className="px-2 py-1 bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 rounded-lg text-xs text-slate-600 dark:text-slate-300 font-medium">
                                  {set.w > 0 ? `${set.w}kg` : "PC"} × {set.r}
                                </span>
                              ))}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </Card>
          </motion.div>
        ))}
      </div>
    </div>
  );
};
