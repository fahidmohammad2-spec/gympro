import React, { useState } from "react";
import { motion } from "framer-motion";
import { Calculator, ChevronDown, ChevronUp, Info } from "lucide-react";
import { Card } from "@/components/ui/Card";
import { Badge } from "@/components/ui/Badge";

const calculators = [
  {
    id: "bmi", title: "IMC", subtitle: "Índice de Masa Corporal", emoji: "⚖️",
    result: { value: "24.6", label: "Normal", color: "text-emerald-500", badge: "success" as const },
    inputs: [
      { label: "Peso (kg)", default: "78", type: "number" },
      { label: "Altura (cm)", default: "178", type: "number" },
    ],
    formula: "IMC = Peso / (Altura²)",
    info: "El IMC es una medida de la grasa corporal basada en el peso y la altura.",
    ranges: [
      { label: "Bajo peso", range: "< 18.5", color: "text-blue-500" },
      { label: "Normal", range: "18.5 – 24.9", color: "text-emerald-500" },
      { label: "Sobrepeso", range: "25 – 29.9", color: "text-amber-500" },
      { label: "Obesidad", range: "≥ 30", color: "text-red-500" },
    ]
  },
  {
    id: "bmr", title: "TMB", subtitle: "Tasa Metabólica Basal", emoji: "🔥",
    result: { value: "1,847", label: "kcal/día", color: "text-orange-500", badge: "warning" as const },
    inputs: [
      { label: "Peso (kg)", default: "78", type: "number" },
      { label: "Altura (cm)", default: "178", type: "number" },
      { label: "Edad (años)", default: "29", type: "number" },
      { label: "Sexo", default: "Masculino", type: "select" },
    ],
    formula: "TMB = 10 × Peso + 6.25 × Altura − 5 × Edad + 5",
    info: "Las calorías mínimas que tu cuerpo necesita en reposo absoluto.",
    ranges: []
  },
  {
    id: "tdee", title: "TDEE", subtitle: "Gasto calórico diario total", emoji: "⚡",
    result: { value: "2,863", label: "kcal/día", color: "text-indigo-500", badge: "info" as const },
    inputs: [
      { label: "TMB (kcal)", default: "1847", type: "number" },
      { label: "Nivel de actividad", default: "Moderado (3-5 días)", type: "select" },
    ],
    formula: "TDEE = TMB × Factor de actividad",
    info: "Calorías totales que quemas en un día normal incluyendo actividad.",
    ranges: []
  },
  {
    id: "macros", title: "Macros", subtitle: "Distribución de macronutrientes", emoji: "🥗",
    result: { value: "P: 157g / C: 286g / G: 95g", label: "Para déficit −200 kcal", color: "text-purple-500", badge: "purple" as const },
    inputs: [
      { label: "TDEE (kcal)", default: "2863", type: "number" },
      { label: "Objetivo", default: "Déficit (−200 kcal)", type: "select" },
      { label: "% Proteína", default: "30", type: "number" },
    ],
    formula: "Proteína: 4 kcal/g · Carbos: 4 kcal/g · Grasa: 9 kcal/g",
    info: "Distribución óptima de macros según tu objetivo.",
    ranges: []
  },
  {
    id: "1rm", title: "1RM", subtitle: "Repetición máxima estimada", emoji: "🏆",
    result: { value: "106 kg", label: "Press de Banca", color: "text-amber-500", badge: "warning" as const },
    inputs: [
      { label: "Peso levantado (kg)", default: "90", type: "number" },
      { label: "Repeticiones", default: "8", type: "number" },
      { label: "Fórmula", default: "Epley", type: "select" },
    ],
    formula: "1RM = Peso × (1 + Reps/30) (Epley)",
    info: "Estimación del peso máximo que puedes levantar en una sola repetición.",
    ranges: []
  },
  {
    id: "water", title: "Agua", subtitle: "Hidratación diaria recomendada", emoji: "💧",
    result: { value: "2.8 L", label: "día de entrenamiento", color: "text-blue-500", badge: "info" as const },
    inputs: [
      { label: "Peso (kg)", default: "78", type: "number" },
      { label: "Actividad física", default: "Alta (entrena)", type: "select" },
      { label: "Clima", default: "Templado", type: "select" },
    ],
    formula: "Agua = Peso × 35ml (+ ajuste por actividad)",
    info: "Cantidad de agua recomendada según tu peso y nivel de actividad.",
    ranges: []
  },
];

export const CalculatorsScreen: React.FC = () => {
  const [expanded, setExpanded] = useState<string | null>("bmi");

  return (
    <div className="space-y-4">
      <p className="text-sm text-slate-500 dark:text-slate-400">
        Calculadoras de fitness y nutrición con tus datos actuales precargados.
      </p>

      {calculators.map((calc, i) => (
        <motion.div
          key={calc.id}
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: i * 0.06 }}
        >
          <Card>
            <button
              onClick={() => setExpanded(expanded === calc.id ? null : calc.id)}
              className="w-full p-4 flex items-center gap-3 hover:bg-slate-50 dark:hover:bg-slate-700/30 transition-colors rounded-2xl text-left"
            >
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-indigo-50 to-purple-50 dark:from-indigo-950/40 dark:to-purple-950/40 border border-indigo-100 dark:border-indigo-900/40 flex items-center justify-center text-2xl shrink-0">
                {calc.emoji}
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <p className="font-bold text-slate-800 dark:text-slate-100">{calc.title}</p>
                  <Badge variant="default" className="text-[10px] hidden sm:flex">{calc.subtitle}</Badge>
                </div>
                <p className={`font-black text-lg ${calc.result.color}`}>{calc.result.value}</p>
                <p className="text-xs text-slate-400">{calc.result.label}</p>
              </div>
              {expanded === calc.id ? (
                <ChevronUp size={18} className="text-slate-400 shrink-0" />
              ) : (
                <ChevronDown size={18} className="text-slate-400 shrink-0" />
              )}
            </button>

            {expanded === calc.id && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: "auto" }}
                className="overflow-hidden"
              >
                <div className="px-4 pb-4 space-y-4">
                  <div className="h-px bg-slate-100 dark:bg-slate-700" />

                  {/* Info box */}
                  <div className="flex items-start gap-2 p-3 bg-indigo-50 dark:bg-indigo-950/30 rounded-xl border border-indigo-100 dark:border-indigo-900/40">
                    <Info size={14} className="text-indigo-500 mt-0.5 shrink-0" />
                    <p className="text-xs text-indigo-600 dark:text-indigo-400">{calc.info}</p>
                  </div>

                  {/* Inputs grid */}
                  <div className={`grid gap-3 ${calc.inputs.length > 2 ? "grid-cols-2" : "grid-cols-2"}`}>
                    {calc.inputs.map((input) => (
                      <div key={input.label}>
                        <label className="text-xs font-medium text-slate-600 dark:text-slate-400 mb-1 block">{input.label}</label>
                        {input.type === "select" ? (
                          <select className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-600 bg-white dark:bg-slate-700/50 text-slate-800 dark:text-slate-100 text-sm focus:outline-none focus:border-indigo-500">
                            <option>{input.default}</option>
                          </select>
                        ) : (
                          <input
                            type="number"
                            defaultValue={input.default}
                            className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-600 bg-white dark:bg-slate-700/50 text-slate-800 dark:text-slate-100 text-sm focus:outline-none focus:border-indigo-500"
                          />
                        )}
                      </div>
                    ))}
                  </div>

                  {/* Result */}
                  <div className="p-4 bg-gradient-to-r from-indigo-50 to-purple-50 dark:from-indigo-950/30 dark:to-purple-950/30 rounded-xl border border-indigo-100 dark:border-indigo-900/40">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-xs text-slate-500 dark:text-slate-400 mb-0.5">Resultado</p>
                        <p className={`text-3xl font-black ${calc.result.color}`}>{calc.result.value}</p>
                        <p className="text-xs text-slate-500 dark:text-slate-400">{calc.result.label}</p>
                      </div>
                      <Badge variant={calc.result.badge}>{calc.result.label}</Badge>
                    </div>

                    {/* Ranges */}
                    {calc.ranges.length > 0 && (
                      <div className="mt-3 grid grid-cols-2 gap-1.5">
                        {calc.ranges.map(r => (
                          <div key={r.label} className="flex items-center justify-between text-xs">
                            <span className={r.color + " font-medium"}>{r.label}</span>
                            <span className="text-slate-400">{r.range}</span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* Formula */}
                  <div className="p-3 bg-slate-50 dark:bg-slate-700/50 rounded-xl">
                    <p className="text-[10px] text-slate-400 mb-1 flex items-center gap-1">
                      <Calculator size={10} /> Fórmula utilizada
                    </p>
                    <p className="text-xs font-mono text-slate-600 dark:text-slate-400">{calc.formula}</p>
                  </div>

                  {/* Recalculate button */}
                  <button className="w-full py-2.5 bg-indigo-600 text-white font-semibold rounded-xl hover:bg-indigo-700 transition-colors text-sm flex items-center justify-center gap-2">
                    <Calculator size={15} />
                    Recalcular
                  </button>
                </div>
              </motion.div>
            )}
          </Card>
        </motion.div>
      ))}
    </div>
  );
};
