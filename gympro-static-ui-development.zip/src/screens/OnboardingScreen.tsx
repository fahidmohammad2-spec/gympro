import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ChevronRight, ChevronLeft, Check, Dumbbell } from "lucide-react";
import { cn } from "@/utils/cn";

interface OnboardingScreenProps {
  onNavigate: (page: string) => void;
}

const objectives = [
  { id: "fat", icon: "🔥", label: "Perder grasa", desc: "Reducir % de grasa corporal" },
  { id: "muscle", icon: "💪", label: "Ganar músculo", desc: "Aumentar masa muscular" },
  { id: "strength", icon: "⚡", label: "Mejorar fuerza", desc: "Levantar más peso" },
  { id: "endurance", icon: "🏃", label: "Resistencia", desc: "Mejorar capacidad aeróbica" },
  { id: "health", icon: "❤️", label: "Salud general", desc: "Estilo de vida saludable" },
  { id: "sport", icon: "🏋️", label: "Deporte específico", desc: "Rendimiento deportivo" },
];

const levels = [
  { id: "beginner", label: "Principiante", desc: "Menos de 6 meses entrenando", icon: "🌱" },
  { id: "intermediate", label: "Intermedio", desc: "6 meses a 2 años de experiencia", icon: "💫" },
  { id: "advanced", label: "Avanzado", desc: "Más de 2 años de experiencia", icon: "🚀" },
];

const frequencies = [
  { id: "2", label: "2 días/semana", desc: "Perfecto para empezar" },
  { id: "3", label: "3 días/semana", desc: "Equilibrio ideal" },
  { id: "4", label: "4 días/semana", desc: "Para buenos resultados" },
  { id: "5", label: "5+ días/semana", desc: "Alto rendimiento" },
];

export const OnboardingScreen: React.FC<OnboardingScreenProps> = ({ onNavigate }) => {
  const [step, setStep] = useState(0);
  const [selectedObjectives, setSelectedObjectives] = useState<string[]>(["muscle"]);
  const [selectedLevel, setSelectedLevel] = useState("intermediate");
  const [selectedFrequency, setSelectedFrequency] = useState("4");
  const [height, setHeight] = useState("178");
  const [weight, setWeight] = useState("78");
  const [targetWeight, setTargetWeight] = useState("75");

  const totalSteps = 4;

  const toggleObjective = (id: string) => {
    setSelectedObjectives(prev =>
      prev.includes(id) ? prev.filter(o => o !== id) : [...prev, id]
    );
  };

  const steps = [
    {
      title: "¿Cuál es tu objetivo?",
      subtitle: "Puedes seleccionar varios",
      content: (
        <div className="grid grid-cols-2 gap-3">
          {objectives.map((obj) => (
            <button
              key={obj.id}
              onClick={() => toggleObjective(obj.id)}
              className={cn(
                "p-4 rounded-2xl border-2 text-left transition-all duration-200 hover:scale-[1.02]",
                selectedObjectives.includes(obj.id)
                  ? "border-indigo-500 bg-indigo-50 dark:bg-indigo-950/40"
                  : "border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 hover:border-slate-300"
              )}
            >
              <div className="text-2xl mb-2">{obj.icon}</div>
              <p className="font-semibold text-sm text-slate-800 dark:text-slate-100">{obj.label}</p>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">{obj.desc}</p>
              {selectedObjectives.includes(obj.id) && (
                <div className="mt-2 flex justify-end">
                  <div className="w-5 h-5 rounded-full bg-indigo-500 flex items-center justify-center">
                    <Check size={12} className="text-white" />
                  </div>
                </div>
              )}
            </button>
          ))}
        </div>
      ),
    },
    {
      title: "Nivel de experiencia",
      subtitle: "Personalizaremos tu plan",
      content: (
        <div className="space-y-3">
          {levels.map((level) => (
            <button
              key={level.id}
              onClick={() => setSelectedLevel(level.id)}
              className={cn(
                "w-full p-4 rounded-2xl border-2 flex items-center gap-4 transition-all duration-200",
                selectedLevel === level.id
                  ? "border-indigo-500 bg-indigo-50 dark:bg-indigo-950/40"
                  : "border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 hover:border-slate-300"
              )}
            >
              <span className="text-3xl">{level.icon}</span>
              <div className="flex-1 text-left">
                <p className="font-semibold text-slate-800 dark:text-slate-100">{level.label}</p>
                <p className="text-xs text-slate-500 dark:text-slate-400">{level.desc}</p>
              </div>
              <div className={cn(
                "w-5 h-5 rounded-full border-2 flex items-center justify-center transition-all",
                selectedLevel === level.id
                  ? "border-indigo-500 bg-indigo-500"
                  : "border-slate-300 dark:border-slate-600"
              )}>
                {selectedLevel === level.id && <Check size={12} className="text-white" />}
              </div>
            </button>
          ))}
        </div>
      ),
    },
    {
      title: "Frecuencia de entrenamiento",
      subtitle: "¿Cuántos días por semana?",
      content: (
        <div className="grid grid-cols-2 gap-3">
          {frequencies.map((freq) => (
            <button
              key={freq.id}
              onClick={() => setSelectedFrequency(freq.id)}
              className={cn(
                "p-4 rounded-2xl border-2 text-center transition-all duration-200",
                selectedFrequency === freq.id
                  ? "border-indigo-500 bg-indigo-50 dark:bg-indigo-950/40"
                  : "border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 hover:border-slate-300"
              )}
            >
              <p className="text-2xl font-black text-indigo-500">{freq.id}</p>
              <p className="font-semibold text-sm text-slate-800 dark:text-slate-100">{freq.label}</p>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">{freq.desc}</p>
            </button>
          ))}
        </div>
      ),
    },
    {
      title: "Datos físicos",
      subtitle: "Para calcular tu plan nutricional",
      content: (
        <div className="space-y-5">
          {/* Height */}
          <div>
            <label className="text-sm font-medium text-slate-700 dark:text-slate-300 mb-2 block">
              Altura (cm)
            </label>
            <div className="flex items-center gap-4">
              <button
                onClick={() => setHeight(String(Math.max(140, Number(height) - 1)))}
                className="w-10 h-10 rounded-full bg-slate-100 dark:bg-slate-700 flex items-center justify-center font-bold text-slate-600 dark:text-slate-300 hover:bg-indigo-100 dark:hover:bg-indigo-900 transition-colors"
              >
                −
              </button>
              <div className="flex-1 text-center">
                <span className="text-4xl font-black text-indigo-500">{height}</span>
                <span className="text-slate-500 ml-2">cm</span>
              </div>
              <button
                onClick={() => setHeight(String(Math.min(220, Number(height) + 1)))}
                className="w-10 h-10 rounded-full bg-slate-100 dark:bg-slate-700 flex items-center justify-center font-bold text-slate-600 dark:text-slate-300 hover:bg-indigo-100 dark:hover:bg-indigo-900 transition-colors"
              >
                +
              </button>
            </div>
            <input type="range" min="140" max="220" value={height}
              onChange={e => setHeight(e.target.value)}
              className="w-full mt-3 accent-indigo-500" />
          </div>

          {/* Weight */}
          <div>
            <label className="text-sm font-medium text-slate-700 dark:text-slate-300 mb-2 block">
              Peso actual (kg)
            </label>
            <div className="flex items-center gap-4">
              <button
                onClick={() => setWeight(String(Math.max(30, Number(weight) - 1)))}
                className="w-10 h-10 rounded-full bg-slate-100 dark:bg-slate-700 flex items-center justify-center font-bold text-slate-600 dark:text-slate-300 hover:bg-indigo-100 dark:hover:bg-indigo-900 transition-colors"
              >
                −
              </button>
              <div className="flex-1 text-center">
                <span className="text-4xl font-black text-indigo-500">{weight}</span>
                <span className="text-slate-500 ml-2">kg</span>
              </div>
              <button
                onClick={() => setWeight(String(Math.min(200, Number(weight) + 1)))}
                className="w-10 h-10 rounded-full bg-slate-100 dark:bg-slate-700 flex items-center justify-center font-bold text-slate-600 dark:text-slate-300 hover:bg-indigo-100 dark:hover:bg-indigo-900 transition-colors"
              >
                +
              </button>
            </div>
            <input type="range" min="30" max="200" value={weight}
              onChange={e => setWeight(e.target.value)}
              className="w-full mt-3 accent-indigo-500" />
          </div>

          {/* Target weight */}
          <div>
            <label className="text-sm font-medium text-slate-700 dark:text-slate-300 mb-2 block">
              Peso objetivo (kg)
            </label>
            <div className="flex items-center gap-4">
              <button
                onClick={() => setTargetWeight(String(Math.max(30, Number(targetWeight) - 1)))}
                className="w-10 h-10 rounded-full bg-slate-100 dark:bg-slate-700 flex items-center justify-center font-bold text-slate-600 dark:text-slate-300 hover:bg-indigo-100 dark:hover:bg-indigo-900 transition-colors"
              >
                −
              </button>
              <div className="flex-1 text-center">
                <span className="text-4xl font-black text-emerald-500">{targetWeight}</span>
                <span className="text-slate-500 ml-2">kg</span>
              </div>
              <button
                onClick={() => setTargetWeight(String(Math.min(200, Number(targetWeight) + 1)))}
                className="w-10 h-10 rounded-full bg-slate-100 dark:bg-slate-700 flex items-center justify-center font-bold text-slate-600 dark:text-slate-300 hover:bg-indigo-100 dark:hover:bg-indigo-900 transition-colors"
              >
                +
              </button>
            </div>
            <input type="range" min="30" max="200" value={targetWeight}
              onChange={e => setTargetWeight(e.target.value)}
              className="w-full mt-3 accent-emerald-500" />
          </div>
        </div>
      ),
    },
  ];

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex flex-col">
      {/* Header */}
      <div className="bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-700 px-6 py-4">
        <div className="max-w-lg mx-auto">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center">
                <Dumbbell size={16} className="text-white" />
              </div>
              <span className="font-black text-slate-800 dark:text-white">GymPro</span>
            </div>
            <span className="text-sm text-slate-500 dark:text-slate-400">
              {step + 1} / {totalSteps}
            </span>
          </div>
          {/* Progress */}
          <div className="flex gap-1.5">
            {Array.from({ length: totalSteps }).map((_, i) => (
              <div key={i} className={cn(
                "flex-1 h-1.5 rounded-full transition-all duration-500",
                i <= step ? "bg-indigo-500" : "bg-slate-200 dark:bg-slate-700"
              )} />
            ))}
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto p-6">
        <div className="max-w-lg mx-auto">
          <AnimatePresence mode="wait">
            <motion.div
              key={step}
              initial={{ opacity: 0, x: 30 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -30 }}
              transition={{ duration: 0.3 }}
            >
              <h2 className="text-2xl font-black text-slate-800 dark:text-white mb-1">
                {steps[step].title}
              </h2>
              <p className="text-slate-500 dark:text-slate-400 text-sm mb-6">
                {steps[step].subtitle}
              </p>
              {steps[step].content}
            </motion.div>
          </AnimatePresence>
        </div>
      </div>

      {/* Footer */}
      <div className="bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-700 px-6 py-4">
        <div className="max-w-lg mx-auto flex gap-3">
          {step > 0 && (
            <button
              onClick={() => setStep(s => s - 1)}
              className="flex items-center gap-2 px-5 py-3 border-2 border-slate-200 dark:border-slate-700 rounded-xl text-slate-600 dark:text-slate-300 font-semibold hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors"
            >
              <ChevronLeft size={18} />
              Anterior
            </button>
          )}
          <button
            onClick={() => {
              if (step < totalSteps - 1) {
                setStep(s => s + 1);
              } else {
                onNavigate("dashboard");
              }
            }}
            className="flex-1 flex items-center justify-center gap-2 py-3 bg-gradient-to-r from-indigo-500 to-purple-600 text-white font-bold rounded-xl hover:shadow-lg hover:shadow-indigo-500/30 transition-all duration-200 btn-press"
          >
            {step < totalSteps - 1 ? (
              <>Siguiente <ChevronRight size={18} /></>
            ) : (
              <>¡Finalizar y empezar! 🚀</>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
