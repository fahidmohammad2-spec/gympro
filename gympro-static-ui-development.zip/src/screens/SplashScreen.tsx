import React from "react";
import { motion } from "framer-motion";
import { Dumbbell, Zap } from "lucide-react";

interface SplashScreenProps {
  onFinish: () => void;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({ onFinish }) => {
  return (
    <div className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-gradient-to-br from-slate-900 via-indigo-950 to-purple-950 overflow-hidden">
      {/* Background particles */}
      <div className="absolute inset-0 overflow-hidden">
        {[...Array(20)].map((_, i) => (
          <div
            key={i}
            className="absolute rounded-full bg-indigo-500/10"
            style={{
              width: `${Math.random() * 200 + 50}px`,
              height: `${Math.random() * 200 + 50}px`,
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 3}s`,
              animationDuration: `${Math.random() * 4 + 3}s`,
            }}
          />
        ))}
        {/* Glow circles */}
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-indigo-600/20 rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 right-1/4 w-64 h-64 bg-purple-600/20 rounded-full blur-3xl" />
      </div>

      <div className="relative flex flex-col items-center gap-8">
        {/* Logo container */}
        <motion.div
          initial={{ scale: 0, rotate: -180 }}
          animate={{ scale: 1, rotate: 0 }}
          transition={{ type: "spring", stiffness: 200, damping: 15, delay: 0.2 }}
          className="relative"
        >
          {/* Pulse rings */}
          <div className="absolute inset-0 rounded-full bg-indigo-500/30 animate-pulse-ring scale-150" />
          <div className="absolute inset-0 rounded-full bg-purple-500/20 animate-pulse-ring scale-125"
            style={{ animationDelay: "0.5s" }} />

          <div className="w-28 h-28 rounded-3xl bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center shadow-2xl shadow-indigo-500/50 glow-indigo">
            <Dumbbell size={52} className="text-white animate-dumbbell" />
          </div>
        </motion.div>

        {/* Text */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6, duration: 0.6 }}
          className="text-center"
        >
          <h1 className="text-7xl font-black text-white tracking-tight leading-none mb-2">
            Gym<span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 to-purple-400">Pro</span>
          </h1>
          <div className="flex items-center justify-center gap-2 text-slate-400 text-sm font-medium">
            <Zap size={14} className="text-amber-400" />
            <span>Train Smarter. Get Stronger.</span>
            <Zap size={14} className="text-amber-400" />
          </div>
        </motion.div>

        {/* Stats row */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1, duration: 0.5 }}
          className="flex items-center gap-8 text-center"
        >
          {[
            { value: "500+", label: "Ejercicios" },
            { value: "50K+", label: "Usuarios" },
            { value: "4.9★", label: "Valoración" },
          ].map((stat) => (
            <div key={stat.label}>
              <p className="text-2xl font-black text-white">{stat.value}</p>
              <p className="text-xs text-slate-400 mt-0.5">{stat.label}</p>
            </div>
          ))}
        </motion.div>

        {/* Progress bar */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.8, duration: 0.4 }}
          className="w-72"
        >
          <div className="flex justify-between text-xs text-slate-500 mb-2">
            <span>Iniciando...</span>
            <span>100%</span>
          </div>
          <div className="h-1.5 bg-slate-800 rounded-full overflow-hidden">
            <div className="h-full bg-gradient-to-r from-indigo-500 to-purple-500 rounded-full splash-progress" />
          </div>
        </motion.div>

        {/* CTA Button (appears after progress) */}
        <motion.button
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 2.2, duration: 0.4 }}
          onClick={onFinish}
          className="mt-2 px-10 py-3.5 bg-gradient-to-r from-indigo-500 to-purple-600 text-white font-bold rounded-2xl shadow-xl shadow-indigo-500/30 hover:shadow-indigo-500/50 hover:scale-105 transition-all duration-200 text-sm"
        >
          ¡Comienza ahora! 🚀
        </motion.button>
      </div>

      {/* Version */}
      <motion.p
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.5 }}
        className="absolute bottom-8 text-xs text-slate-600"
      >
        GymPro v2.0.0 • © 2025 GymPro Inc.
      </motion.p>
    </div>
  );
};
