import React from "react";
import {
  Dumbbell, LayoutDashboard, BookOpen, Calendar, PlayCircle,
  History, Apple, TrendingUp, Calculator, Users, User, Settings,
  Shield, ChevronRight, LogOut
} from "lucide-react";
import { cn } from "@/utils/cn";

interface NavItem {
  id: string;
  label: string;
  icon: React.ReactNode;
  badge?: string;
}

const navItems: NavItem[] = [
  { id: "dashboard", label: "Inicio", icon: <LayoutDashboard size={18} /> },
  { id: "exercises", label: "Ejercicios", icon: <BookOpen size={18} /> },
  { id: "routines", label: "Mis Rutinas", icon: <Calendar size={18} /> },
  { id: "workout", label: "Entrenar", icon: <PlayCircle size={18} />, badge: "HOY" },
  { id: "history", label: "Historial", icon: <History size={18} /> },
  { id: "nutrition", label: "Nutrición", icon: <Apple size={18} /> },
  { id: "progress", label: "Progreso", icon: <TrendingUp size={18} /> },
  { id: "calculators", label: "Calculadoras", icon: <Calculator size={18} /> },
  { id: "community", label: "Comunidad", icon: <Users size={18} /> },
  { id: "profile", label: "Perfil", icon: <User size={18} /> },
  { id: "admin", label: "Admin Panel", icon: <Shield size={18} /> },
];

interface SidebarProps {
  currentPage: string;
  onNavigate: (page: string) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ currentPage, onNavigate }) => {
  return (
    <aside className="hidden lg:flex flex-col w-64 min-h-screen bg-white dark:bg-slate-900 border-r border-slate-200 dark:border-slate-700/60 fixed left-0 top-0 z-30">
      {/* Logo */}
      <div className="p-5 border-b border-slate-100 dark:border-slate-700/60">
        <button
          onClick={() => onNavigate("splash")}
          className="flex items-center gap-3 group"
        >
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center shadow-lg group-hover:scale-105 transition-transform">
            <Dumbbell size={20} className="text-white" />
          </div>
          <div>
            <p className="font-black text-lg text-slate-800 dark:text-white leading-none">GymPro</p>
            <p className="text-xs text-slate-400 dark:text-slate-500">v2.0 Premium</p>
          </div>
        </button>
      </div>

      {/* User quick info */}
      <div className="p-4 mx-3 mt-4 rounded-xl bg-gradient-to-r from-indigo-50 to-purple-50 dark:from-indigo-950/40 dark:to-purple-950/40 border border-indigo-100 dark:border-indigo-900/40">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-full bg-gradient-to-br from-indigo-400 to-purple-500 flex items-center justify-center text-white font-bold text-sm">
            CA
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-semibold text-slate-700 dark:text-slate-200 truncate">Carlos Andrés</p>
            <p className="text-xs text-indigo-500 dark:text-indigo-400">Nivel Intermedio 🔥 12 días</p>
          </div>
        </div>
      </div>

      {/* Nav */}
      <nav className="flex-1 p-3 space-y-1 mt-2 overflow-y-auto no-scrollbar">
        {navItems.map((item) => (
          <button
            key={item.id}
            onClick={() => onNavigate(item.id)}
            className={cn(
              "w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all duration-200 group",
              currentPage === item.id
                ? "bg-indigo-600 text-white shadow-md shadow-indigo-500/20"
                : "text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 hover:text-slate-800 dark:hover:text-slate-200"
            )}
          >
            <span className={cn(
              "transition-colors",
              currentPage === item.id ? "text-white" : "text-slate-400 group-hover:text-indigo-500"
            )}>
              {item.icon}
            </span>
            <span className="flex-1 text-left">{item.label}</span>
            {item.badge && (
              <span className="text-[10px] bg-amber-400 text-amber-900 font-bold px-1.5 py-0.5 rounded-full">
                {item.badge}
              </span>
            )}
            {currentPage === item.id && <ChevronRight size={14} />}
          </button>
        ))}
      </nav>

      {/* Bottom actions */}
      <div className="p-3 border-t border-slate-100 dark:border-slate-700/60 space-y-1">
        <button
          onClick={() => onNavigate("settings")}
          className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
        >
          <Settings size={18} className="text-slate-400" />
          Configuración
        </button>
        <button
          onClick={() => onNavigate("auth")}
          className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-red-500 hover:bg-red-50 dark:hover:bg-red-950/30 transition-colors"
        >
          <LogOut size={18} />
          Cerrar sesión
        </button>
      </div>
    </aside>
  );
};
