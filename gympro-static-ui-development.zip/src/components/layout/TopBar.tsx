import React from "react";
import { Bell, Moon, Sun, Search, Dumbbell } from "lucide-react";
import { cn } from "@/utils/cn";

interface TopBarProps {
  title: string;
  darkMode: boolean;
  onToggleDark: () => void;
  onNavigate: (page: string) => void;
}

export const TopBar: React.FC<TopBarProps> = ({ title, darkMode, onToggleDark, onNavigate }) => {
  return (
    <header className="sticky top-0 z-20 bg-white/90 dark:bg-slate-900/90 backdrop-blur-xl border-b border-slate-200/60 dark:border-slate-700/60">
      <div className="flex items-center justify-between px-4 lg:px-6 h-16">
        {/* Mobile Logo */}
        <div className="flex items-center gap-2 lg:hidden">
          <button onClick={() => onNavigate("splash")} className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center">
              <Dumbbell size={16} className="text-white" />
            </div>
            <span className="font-black text-slate-800 dark:text-white">GymPro</span>
          </button>
        </div>

        {/* Desktop title */}
        <h1 className="hidden lg:block text-xl font-bold text-slate-800 dark:text-white">{title}</h1>

        {/* Right actions */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => onNavigate("exercises")}
            className="p-2 rounded-xl text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 hover:text-indigo-500 transition-colors"
          >
            <Search size={18} />
          </button>
          <div className="relative">
            <button className="p-2 rounded-xl text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 hover:text-indigo-500 transition-colors">
              <Bell size={18} />
            </button>
            <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-red-500 rounded-full border-2 border-white dark:border-slate-900" />
          </div>
          <button
            onClick={onToggleDark}
            className={cn(
              "p-2 rounded-xl transition-all duration-300",
              darkMode
                ? "bg-indigo-600 text-white hover:bg-indigo-700"
                : "text-slate-500 hover:bg-slate-100 hover:text-indigo-500"
            )}
          >
            {darkMode ? <Sun size={18} /> : <Moon size={18} />}
          </button>
          <button
            onClick={() => onNavigate("profile")}
            className="w-8 h-8 rounded-full bg-gradient-to-br from-indigo-400 to-purple-500 flex items-center justify-center text-white font-bold text-xs hover:scale-105 transition-transform"
          >
            CA
          </button>
        </div>
      </div>
    </header>
  );
};
