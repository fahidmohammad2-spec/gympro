import React from "react";
import {
  LayoutDashboard, BookOpen, PlayCircle, Apple, User
} from "lucide-react";
import { cn } from "@/utils/cn";

interface BottomNavProps {
  currentPage: string;
  onNavigate: (page: string) => void;
}

const mobileNavItems = [
  { id: "dashboard", label: "Inicio", icon: <LayoutDashboard size={20} /> },
  { id: "exercises", label: "Ejercicios", icon: <BookOpen size={20} /> },
  { id: "workout", label: "Entrenar", icon: <PlayCircle size={22} />, main: true },
  { id: "nutrition", label: "Nutrición", icon: <Apple size={20} /> },
  { id: "profile", label: "Perfil", icon: <User size={20} /> },
];

export const BottomNav: React.FC<BottomNavProps> = ({ currentPage, onNavigate }) => {
  return (
    <nav className="lg:hidden fixed bottom-0 left-0 right-0 z-30 bg-white/95 dark:bg-slate-900/95 backdrop-blur-xl border-t border-slate-200 dark:border-slate-700/60 safe-area-inset-bottom">
      <div className="flex items-center justify-around px-2 h-16">
        {mobileNavItems.map((item) => (
          <button
            key={item.id}
            onClick={() => onNavigate(item.id)}
            className={cn(
              "flex flex-col items-center justify-center gap-1 flex-1 h-full transition-all duration-200",
              item.main
                ? "relative -top-4"
                : ""
            )}
          >
            {item.main ? (
              <div className={cn(
                "w-14 h-14 rounded-2xl flex items-center justify-center shadow-lg transition-all duration-200",
                currentPage === item.id
                  ? "bg-indigo-700 scale-110"
                  : "bg-gradient-to-br from-indigo-500 to-purple-600 hover:scale-105"
              )}>
                <span className="text-white">{item.icon}</span>
              </div>
            ) : (
              <>
                <span className={cn(
                  "transition-colors duration-200",
                  currentPage === item.id
                    ? "text-indigo-600 dark:text-indigo-400"
                    : "text-slate-400 dark:text-slate-500"
                )}>
                  {item.icon}
                </span>
                <span className={cn(
                  "text-[10px] font-medium transition-colors duration-200",
                  currentPage === item.id
                    ? "text-indigo-600 dark:text-indigo-400"
                    : "text-slate-400 dark:text-slate-500"
                )}>
                  {item.label}
                </span>
              </>
            )}
          </button>
        ))}
      </div>
    </nav>
  );
};
