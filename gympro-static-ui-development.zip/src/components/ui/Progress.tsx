import React from "react";
import { cn } from "@/utils/cn";

interface ProgressProps {
  value: number;
  max?: number;
  color?: string;
  className?: string;
  label?: string;
  showLabel?: boolean;
  size?: "xs" | "sm" | "md";
  animated?: boolean;
}

export const Progress: React.FC<ProgressProps> = ({
  value,
  max = 100,
  color = "bg-indigo-500",
  className,
  label,
  showLabel,
  size = "sm",
  animated = true,
}) => {
  const pct = Math.min(100, Math.round((value / max) * 100));
  const heights = { xs: "h-1.5", sm: "h-2.5", md: "h-4" };

  return (
    <div className={cn("w-full", className)}>
      {(label || showLabel) && (
        <div className="flex justify-between text-xs text-slate-500 dark:text-slate-400 mb-1">
          {label && <span>{label}</span>}
          {showLabel && <span>{value}/{max}</span>}
        </div>
      )}
      <div className={cn("w-full rounded-full bg-slate-100 dark:bg-slate-700/60 overflow-hidden", heights[size])}>
        <div
          className={cn("h-full rounded-full transition-all duration-700", color, animated && "animate-bar")}
          style={{ width: `${pct}%` }}
        />
      </div>
    </div>
  );
};
