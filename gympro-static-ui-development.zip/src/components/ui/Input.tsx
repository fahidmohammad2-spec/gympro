import React from "react";
import { cn } from "@/utils/cn";

interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  icon?: React.ReactNode;
  error?: string;
}

export const Input: React.FC<InputProps> = ({ label, icon, error, className, ...props }) => (
  <div className="flex flex-col gap-1.5 w-full">
    {label && (
      <label className="text-sm font-medium text-slate-700 dark:text-slate-300">
        {label}
      </label>
    )}
    <div className="relative">
      {icon && (
        <div className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 dark:text-slate-500">
          {icon}
        </div>
      )}
      <input
        className={cn(
          "w-full rounded-xl border border-slate-200 dark:border-slate-600 bg-white dark:bg-slate-700/50",
          "text-slate-800 dark:text-slate-100 placeholder:text-slate-400 dark:placeholder:text-slate-500",
          "px-4 py-2.5 text-sm outline-none transition-all duration-200",
          "focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20",
          "hover:border-slate-300 dark:hover:border-slate-500",
          icon && "pl-10",
          error && "border-red-400",
          className
        )}
        {...props}
      />
    </div>
    {error && <p className="text-xs text-red-500">{error}</p>}
  </div>
);

interface SelectProps extends React.SelectHTMLAttributes<HTMLSelectElement> {
  label?: string;
  options: { value: string; label: string }[];
}

export const Select: React.FC<SelectProps> = ({ label, options, className, ...props }) => (
  <div className="flex flex-col gap-1.5 w-full">
    {label && (
      <label className="text-sm font-medium text-slate-700 dark:text-slate-300">
        {label}
      </label>
    )}
    <select
      className={cn(
        "w-full rounded-xl border border-slate-200 dark:border-slate-600 bg-white dark:bg-slate-700/50",
        "text-slate-800 dark:text-slate-100",
        "px-4 py-2.5 text-sm outline-none transition-all duration-200",
        "focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20",
        className
      )}
      {...props}
    >
      {options.map((o) => (
        <option key={o.value} value={o.value}>{o.label}</option>
      ))}
    </select>
  </div>
);

interface TextareaProps extends React.TextareaHTMLAttributes<HTMLTextAreaElement> {
  label?: string;
}

export const Textarea: React.FC<TextareaProps> = ({ label, className, ...props }) => (
  <div className="flex flex-col gap-1.5 w-full">
    {label && (
      <label className="text-sm font-medium text-slate-700 dark:text-slate-300">
        {label}
      </label>
    )}
    <textarea
      className={cn(
        "w-full rounded-xl border border-slate-200 dark:border-slate-600 bg-white dark:bg-slate-700/50",
        "text-slate-800 dark:text-slate-100 placeholder:text-slate-400",
        "px-4 py-2.5 text-sm outline-none transition-all duration-200 resize-none",
        "focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20",
        className
      )}
      {...props}
    />
  </div>
);
